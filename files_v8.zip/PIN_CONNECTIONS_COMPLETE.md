# Complete Op-Amp Pin Connection Guide for Testing

## Overview

Setiap op-amp memiliki konfigurasi pin yang berbeda. Panduan ini menunjukkan cara menghubungkan setiap IC ke Arduino Nano untuk testing.

## 8-Pin DIP Op-Amps (Standar)

Sebagian besar op-amp menggunakan konfigurasi 8-pin DIP standar:
