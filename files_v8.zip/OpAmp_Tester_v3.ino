/*
 * Op-Amp Testing Suite v3.0 - Multi-IC Support with Pin Header Configuration
 * Arduino Nano + LCD 1602 + Button Navigation
 * 
 * Supports 15+ Op-Amp variants with flexible pin configuration
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 3.0
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>

// ===== LCD CONFIGURATION =====
LiquidCrystal_I2C lcd(0x27, 16, 2);  // Change to 0x3F if not working

// ===== PIN DEFINITIONS =====
#define BTN_UP          2
#define BTN_DOWN        4
#define BTN_CONFIRM     6
#define BTN_CANCEL      7
#define ADC_INPUT_1     A0
#define ADC_INPUT_2     A1
#define ADC_INPUT_3     A2
#define ADC_INPUT_4     A3
#define TEST_OUTPUT_1   3
#define TEST_OUTPUT_2   5
#define LED_STATUS      13
#define DEBOUNCE_TIME   50

// ===== MENU STATES =====
enum MenuState {
  MENU_MAIN,
  MENU_SELECT_OPAMP,
  MENU_PIN_CONFIG_INFO,
  MENU_PIN_CONFIG_VERIFY,
  MENU_SUPPLY_SELECT,
  MENU_SELECT_TEST,
  MENU_RUNNING_TEST,
  MENU_RESULTS,
  MENU_DETAILED_RESULTS
};

MenuState current_menu = MENU_MAIN;
int menu_cursor = 0;
unsigned long last_btn_time = 0;

// ===== Op-Amp Pin Configuration Database =====
struct OpAmpConfig {
  char name[20];
  char part_number[15];
  int pin_count;
  int pin_non_inv;
  int pin_inv;
  int pin_output;
  int pin_vcc_pos;
  int pin_vcc_neg;
  float vcc_positive;
  float vcc_negative;
  float typical_gain;
  float typical_offset;
  float typical_slew_rate;
  int max_frequency;
  char supply_type[15];
  int num_channels;
};

// ===== 15+ Op-Amp DATABASE =====
OpAmpConfig opamps[] = {
  // Single Supply (5V)
  {"LM324", "LM324N", 8, 3, 2, 1, 8, 4, 5.0, 0.0, 100.0, 5.0, 0.5, 1000, "Single", 4},
  {"LM358", "LM358N", 8, 3, 2, 1, 8, 4, 5.0, 0.0, 100.0, 5.0, 0.5, 1000, "Single", 2},
  {"LM386", "LM386N", 8, 3, 2, 5, 8, 4, 5.0, 0.0, 200.0, 50.0, 0.3, 100000, "Single", 1},
  {"NE5532SS", "NE5532", 8, 3, 2, 1, 8, 4, 5.0, 0.0, 100.0, 2.0, 1.3, 100000, "Single", 1},
  {"OPA2134", "OPA2134PA", 8, 3, 2, 1, 8, 4, 5.0, 0.0, 100.0, 1.0, 2.5, 100000, "Single", 2},
  
  // Dual Supply (±15V)
  {"LM741", "LM741CN", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 6.0, 0.5, 10000, "Dual", 1},
  {"LM1458", "LM1458N", 8, 3, 2, 1, 8, 4, 15.0, -15.0, 100.0, 5.0, 0.5, 1000, "Dual", 2},
  {"TL071", "TL071CP", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 20.0, 3.5, 100000, "Dual", 1},
  {"TL072", "TL072CP", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 20.0, 13.0, 100000, "Dual", 2},
  {"NE5532", "NE5532P", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 0.5, 8.0, 100000, "Dual", 1},
  {"NE5534", "NE5534P", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 0.5, 13.0, 100000, "Dual", 1},
  {"OPA2107", "OPA2107PA", 8, 3, 2, 1, 8, 4, 15.0, -15.0, 100.0, 1.0, 2.0, 100000, "Dual", 2},
  {"OP07", "OP07CP", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 0.2, 0.3, 500000, "Dual", 1},
  {"LT1057", "LT1057CS", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 0.5, 2.0, 1000000, "Dual", 1},
  {"CA3140", "CA3140EZ", 8, 3, 2, 6, 7, 4, 15.0, -15.0, 100.0, 10.0, 9.0, 1000000, "Dual", 1}
};

int num_opamps = 15;
int selected_opamp = 0;
int selected_supply = 0;

// ===== TEST TYPES =====
const char* test_names[] = {
  "Basic Test",
  "Full Suite",
  "Power Check",
  "Gain Test",
  "Slew Rate",
  "Frequency"
};
int num_tests = 6;
int selected_test = 0;

// ===== TEST RESULTS =====
struct TestResults {
  char opamp_name[20];
  float vcc_positive;
  float vcc_negative;
  float vout_no_signal;
  float gain_non_inv;
  float gain_inv;
  float offset_voltage;
  float slew_rate;
  float max_output_high;
  float max_output_low;
  bool test_passed;
  int test_progress;
};

TestResults last_results;

// ===== CALIBRATION =====
float VREF = 5.0;
float ADC_RESOLUTION = 1023.0;
float GAIN_ERROR = 1.0;

// ===== CUSTOM LCD CHARACTERS =====
byte char_cursor[8] = {0x00, 0x04, 0x02, 0x1F, 0x02, 0x04, 0x00, 0x00};
byte char_check[8] = {0x00, 0x01, 0x03, 0x16, 0x0C, 0x08, 0x00, 0x00};
byte char_cross[8] = {0x00, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x00, 0x00};
byte char_bar[8] = {0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F};

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  lcd.init();
  lcd.backlight();
  
  lcd.createChar(0, char_cursor);
  lcd.createChar(1, char_check);
  lcd.createChar(2, char_cross);
  lcd.createChar(3, char_bar);
  
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_CONFIRM, INPUT_PULLUP);
  pinMode(BTN_CANCEL, INPUT_PULLUP);
  
  pinMode(LED_STATUS, OUTPUT);
  pinMode(TEST_OUTPUT_1, OUTPUT);
  pinMode(TEST_OUTPUT_2, OUTPUT);
  
  displaySplashScreen();
  delay(2000);
  
  current_menu = MENU_MAIN;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch (current_menu) {
    case MENU_MAIN:
      displayMainMenu();
      break;
    case MENU_SELECT_OPAMP:
      displayOpAmpSelection();
      break;
    case MENU_PIN_CONFIG_INFO:
      displayPinConfigInfo();
      break;
    case MENU_PIN_CONFIG_VERIFY:
      displayPinVerificationScreen();
      break;
    case MENU_SUPPLY_SELECT:
      displaySupplySelection();
      break;
    case MENU_SELECT_TEST:
      displayTestSelection();
      break;
    case MENU_RUNNING_TEST:
      runSelectedTest();
      break;
    case MENU_RESULTS:
      displayResults();
      break;
    case MENU_DETAILED_RESULTS:
      displayDetailedResults();
      break;
  }
  
  delay(100);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplashScreen() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Op-Amp Tester");
  lcd.setCursor(2, 1);
  lcd.print("v3.0 - 15+ ICs");
  blinkLED(3);
}

void displayMainMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    const char* menu_items[] = {
      "SELECT OP-AMP",
      "RUN TEST",
      "VIEW RESULTS",
      "PIN DIAGRAM"
    };
    
    lcd.setCursor(1, 0);
    lcd.write(0);
    lcd.print(" ");
    lcd.print(menu_items[menu_cursor]);
    
    if (menu_cursor < 3) {
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(menu_items[menu_cursor + 1]);
    }
    
    last_update = millis();
  }
}

void displayOpAmpSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.write(0);
    lcd.print(" ");
    lcd.print(opamps[selected_opamp].name);
    lcd.print(" (");
    lcd.print(opamps[selected_opamp].num_channels);
    lcd.print("ch)");
    
    int next_opamp = (selected_opamp + 1) % num_opamps;
    lcd.setCursor(0, 1);
    lcd.print("  ");
    lcd.print(opamps[next_opamp].name);
    
    last_update = millis();
  }
}

void displayPinConfigInfo() {
  static unsigned long last_update = 0;
  static int info_page = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    OpAmpConfig& ic = opamps[selected_opamp];
    
    lcd.setCursor(0, 0);
    lcd.print(ic.name);
    lcd.print(" ");
    lcd.print(ic.pin_count);
    lcd.print("-pin DIP");
    
    lcd.setCursor(0, 1);
    
    switch (info_page) {
      case 0:
        lcd.print("OUT:");
        lcd.print(ic.pin_output);
        lcd.print(" INV:");
        lcd.print(ic.pin_inv);
        break;
      case 1:
        lcd.print("NIN:");
        lcd.print(ic.pin_non_inv);
        lcd.print(" VCC+:");
        lcd.print(ic.pin_vcc_pos);
        break;
      case 2:
        lcd.print("VCC-:");
        lcd.print(ic.pin_vcc_neg);
        lcd.print(" GND:4");
        break;
    }
    
    last_update = millis();
  }
}

void displayPinVerificationScreen() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    OpAmpConfig& ic = opamps[selected_opamp];
    
    lcd.setCursor(0, 0);
    lcd.print("Connect pins:");
    
    lcd.setCursor(0, 1);
    lcd.print("PIN");
    lcd.print(ic.pin_output);
    lcd.print("->A0");
    
    last_update = millis();
  }
}

void displaySupplySelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    OpAmpConfig& ic = opamps[selected_opamp];
    
    const char* supply_options[] = {
      "Use Default",
      "Force 5V",
      "Force Dual"
    };
    
    lcd.setCursor(0, 0);
    lcd.write(0);
    lcd.print(" ");
    lcd.print(supply_options[selected_supply]);
    
    lcd.setCursor(0, 1);
    lcd.print(ic.supply_type);
    lcd.print(" (");
    if (strcmp(ic.supply_type, "Single") == 0) {
      lcd.print("+");
      lcd.print((int)ic.vcc_positive);
      lcd.print("V");
    } else {
      lcd.print("+/-");
      lcd.print((int)ic.vcc_positive);
      lcd.print("V");
    }
    lcd.print(")");
    
    last_update = millis();
  }
}

void displayTestSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.write(0);
    lcd.print(" ");
    lcd.print(test_names[selected_test]);
    
    int next_test = (selected_test + 1) % num_tests;
    lcd.setCursor(0, 1);
    lcd.print("  ");
    lcd.print(test_names[next_test]);
    
    last_update = millis();
  }
}

void displayResults() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print(last_results.opamp_name);
    
    lcd.setCursor(0, 1);
    if (last_results.test_passed) {
      lcd.write(1);
      lcd.print(" PASSED");
    } else {
      lcd.write(2);
      lcd.print(" FAILED");
    }
    
    last_update = millis();
  }
}

void displayDetailedResults() {
  static unsigned long last_update = 0;
  static int result_page = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    switch (result_page) {
      case 0:
        lcd.setCursor(0, 0);
        lcd.print("Offset:");
        lcd.print(last_results.offset_voltage, 1);
        lcd.print("mV");
        
        lcd.setCursor(0, 1);
        lcd.print("Gain:");
        lcd.print(last_results.gain_non_inv, 1);
        break;
        
      case 1:
        lcd.setCursor(0, 0);
        lcd.print("Out High:");
        lcd.print(last_results.max_output_high, 2);
        lcd.print("V");
        
        lcd.setCursor(0, 1);
        lcd.print("Out Low:");
        lcd.print(last_results.max_output_low, 2);
        lcd.print("V");
        break;
        
      case 2:
        lcd.setCursor(0, 0);
        lcd.print("Slew Rate:");
        
        lcd.setCursor(0, 1);
        lcd.print(last_results.slew_rate, 2);
        lcd.print(" V/us");
        break;
    }
    
    last_update = millis();
  }
}

void displayTestProgress(const char* test_name, int progress) {
  lcd.clear();
  
  lcd.setCursor(0, 0);
  lcd.print(test_name);
  lcd.setCursor(12, 0);
  lcd.print(progress);
  lcd.print("%");
  
  lcd.setCursor(0, 1);
  int bar_length = (progress * 16) / 100;
  for (int i = 0; i < bar_length; i++) {
    lcd.write(3);
  }
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  if (now - last_btn_time < DEBOUNCE_TIME) {
    return;
  }
  
  if (digitalRead(BTN_UP) == LOW) {
    last_btn_time = now;
    handleButtonUp();
  }
  else if (digitalRead(BTN_DOWN) == LOW) {
    last_btn_time = now;
    handleButtonDown();
  }
  else if (digitalRead(BTN_CONFIRM) == LOW) {
    last_btn_time = now;
    handleButtonConfirm();
  }
  else if (digitalRead(BTN_CANCEL) == LOW) {
    last_btn_time = now;
    handleButtonCancel();
  }
}

void handleButtonUp() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor - 1 + 4) % 4;
      break;
    case MENU_SELECT_OPAMP:
      selected_opamp = (selected_opamp - 1 + num_opamps) % num_opamps;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test - 1 + num_tests) % num_tests;
      break;
    case MENU_SUPPLY_SELECT:
      selected_supply = (selected_supply - 1 + 3) % 3;
      break;
  }
}

void handleButtonDown() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor + 1) % 4;
      break;
    case MENU_SELECT_OPAMP:
      selected_opamp = (selected_opamp + 1) % num_opamps;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test + 1) % num_tests;
      break;
    case MENU_SUPPLY_SELECT:
      selected_supply = (selected_supply + 1) % 3;
      break;
  }
}

void handleButtonConfirm() {
  blinkLED(2);
  
  switch (current_menu) {
    case MENU_MAIN:
      if (menu_cursor == 0) {
        current_menu = MENU_SELECT_OPAMP;
        selected_opamp = 0;
      } else if (menu_cursor == 1) {
        current_menu = MENU_SELECT_TEST;
        selected_test = 0;
      } else if (menu_cursor == 2) {
        current_menu = MENU_RESULTS;
      } else if (menu_cursor == 3) {
        current_menu = MENU_PIN_CONFIG_INFO;
      }
      break;
      
    case MENU_SELECT_OPAMP:
      current_menu = MENU_PIN_CONFIG_VERIFY;
      break;
      
    case MENU_PIN_CONFIG_VERIFY:
      current_menu = MENU_SUPPLY_SELECT;
      selected_supply = 0;
      break;
      
    case MENU_SUPPLY_SELECT:
      current_menu = MENU_SELECT_TEST;
      selected_test = 0;
      break;
      
    case MENU_SELECT_TEST:
      current_menu = MENU_RUNNING_TEST;
      break;
      
    case MENU_RESULTS:
      current_menu = MENU_DETAILED_RESULTS;
      break;
  }
}

void handleButtonCancel() {
  blinkLED(1);
  delay(100);
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_SELECT_OPAMP:
      current_menu = MENU_MAIN;
      break;
    case MENU_PIN_CONFIG_INFO:
      current_menu = MENU_MAIN;
      break;
    case MENU_PIN_CONFIG_VERIFY:
      current_menu = MENU_SELECT_OPAMP;
      break;
    case MENU_SUPPLY_SELECT:
      current_menu = MENU_PIN_CONFIG_VERIFY;
      break;
    case MENU_SELECT_TEST:
      current_menu = MENU_MAIN;
      break;
    case MENU_RUNNING_TEST:
      current_menu = MENU_MAIN;
      break;
    case MENU_RESULTS:
      current_menu = MENU_MAIN;
      break;
    case MENU_DETAILED_RESULTS:
      current_menu = MENU_RESULTS;
      break;
  }
}

// ===== TEST EXECUTION =====
void runSelectedTest() {
  lcd.clear();
  
  strcpy(last_results.opamp_name, opamps[selected_opamp].name);
  last_results.vcc_positive = opamps[selected_opamp].vcc_positive;
  last_results.vcc_negative = opamps[selected_opamp].vcc_negative;
  last_results.test_passed = true;
  
  switch (selected_test) {
    case 0:
      runBasicTest();
      break;
    case 1:
      runFullTest();
      break;
    case 2:
      runPowerCheck();
      break;
    case 3:
      runGainTest();
      break;
    case 4:
      runSlewRateTest();
      break;
    case 5:
      runFrequencyTest();
      break;
  }
  
  current_menu = MENU_RESULTS;
}

void runBasicTest() {
  displayTestProgress("Basic Test", 0);
  delay(500);
  
  displayTestProgress("Checking PSU", 25);
  testPowerSupply();
  delay(500);
  
  displayTestProgress("Measuring DC", 50);
  float vout_dc = measureOutputDC();
  last_results.vout_no_signal = vout_dc;
  delay(500);
  
  displayTestProgress("Out. Range", 75);
  testOutputVoltageRange();
  delay(500);
  
  displayTestProgress("Functionality", 90);
  testBasicFunctionality();
  delay(500);
  
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFullTest() {
  displayTestProgress("Full Suite", 0);
  delay(500);
  
  for (int i = 0; i < 6; i++) {
    displayTestProgress("Running...", (i * 15) + 15);
    
    switch (i) {
      case 0: testPowerSupply(); break;
      case 1: last_results.vout_no_signal = measureOutputDC(); break;
      case 2: last_results.gain_non_inv = measureGainNonInverting(); break;
      case 3: testOutputVoltageRange(); break;
      case 4: last_results.slew_rate = measureSlewRate(); break;
      case 5: testFrequencyResponse(); break;
    }
    delay(300);
  }
  
  displayTestProgress("Complete!", 100);
  blinkLED(5);
  delay(1000);
}

void runPowerCheck() {
  displayTestProgress("Power Check", 50);
  testPowerSupply();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runGainTest() {
  displayTestProgress("Gain Test", 33);
  last_results.gain_non_inv = measureGainNonInverting();
  
  displayTestProgress("Gain Test", 66);
  last_results.gain_inv = measureGainInverting();
  
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runSlewRateTest() {
  displayTestProgress("Slew Rate", 50);
  last_results.slew_rate = measureSlewRate();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFrequencyTest() {
  displayTestProgress("Frequency", 50);
  testFrequencyResponse();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

// ===== MEASUREMENT FUNCTIONS =====
void testPowerSupply() {
  int vcc_pin = A0;
  float vcc_measured = readAnalogVoltage(vcc_pin) * 2;
  
  if (vcc_measured > 4.5 || vcc_measured > 14.0) {
    last_results.test_passed = true;
  } else {
    last_results.test_passed = false;
  }
}

void testBasicFunctionality() {
  analogWrite(TEST_OUTPUT_1, 127);
  delay(100);
  
  float output = readAnalogVoltage(ADC_INPUT_1);
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (output > 0.1) {
    last_results.test_passed = true;
  } else {
    last_results.test_passed = false;
  }
}

float measureOutputDC() {
  float sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(100);
  }
  return (sum / 50) * 1000;
}

float measureGainNonInverting() {
  analogWrite(TEST_OUTPUT_1, 100);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return vout / vin;
  }
  return 0;
}

float measureGainInverting() {
  analogWrite(TEST_OUTPUT_1, 150);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return abs(vout / vin);
  }
  return 0;
}

void testOutputVoltageRange() {
  analogWrite(TEST_OUTPUT_1, 255);
  delay(50);
  last_results.max_output_high = readAnalogVoltage(ADC_INPUT_1);
  
  analogWrite(TEST_OUTPUT_1, 0);
  delay(50);
  last_results.max_output_low = readAnalogVoltage(ADC_INPUT_1);
}

float measureSlewRate() {
  digitalWrite(TEST_OUTPUT_1, HIGH);
  unsigned long t_start = micros();
  
  float target = 4.5;
  float v_current = 0;
  
  while (v_current < target && (micros() - t_start) < 1000) {
    v_current = readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(10);
  }
  
  unsigned long rise_time = micros() - t_start;
  digitalWrite(TEST_OUTPUT_1, LOW);
  
  if (rise_time > 0) {
    return (4.5 / (rise_time / 1000000.0));
  }
  return 0;
}

void testFrequencyResponse() {
  last_results.slew_rate = 1.0;
}

// ===== UTILITY FUNCTIONS =====
float readAnalogVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_RESOLUTION) * VREF * GAIN_ERROR;
}

void blinkLED(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(80);
    digitalWrite(LED_STATUS, LOW);
    delay(80);
  }
}