# Modular Socket Setup Guide - Kelompok per Kategori

Panduan untuk memasang IC socket hanya untuk kategori yang Anda butuhkan!

## 📊 5 Kategori IC

### Kategori 1: General Purpose Single Supply (5V)