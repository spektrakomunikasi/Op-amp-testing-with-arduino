/*
 * Op-Amp Functionality Tester v6.0 - SIMPLE VERSION
 * Arduino Nano - Only Check if Op-Amp Still Works
 * 
 * Test Parameters from Datasheet:
 * 1. DC Offset Voltage (should be < max spec)
 * 2. Gain at unity (should be ~1.0x)
 * 3. Output swing (should reach near rails)
 * 4. Response time (should be fast)
 * 
 * That's it! Just PASS or FAIL!
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 6.0 - Simple Functionality Test
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ===== LCD (20x4 recommended) =====
#define LCD_ADDR 0x27
#define LCD_COLS 20
#define LCD_ROWS 4

LiquidCrystal_I2C lcd(LCD_ADDR, LCD_COLS, LCD_ROWS);

// ===== ARDUINO PINS =====
// Only use pins needed for active channels
#define OUT_CH1     3   // PWM - test signal
#define OUT_CH2     5   // PWM - optional
#define OUT_CH3     6   // PWM - optional
#define OUT_CH4     9   // PWM - optional

#define IN_CH1      A0  // ADC - read output
#define IN_CH2      A1  // ADC - optional
#define IN_CH3      A2  // ADC - optional
#define IN_CH4      A3  // ADC - optional

#define BTN_START   2   // Start test
#define BTN_NEXT    4   // Next channel
#define BTN_PREV    7   // Previous channel
#define BTN_MENU    8   // Back to menu

#define LED_OK      13  // Green indicator (or PWM for brightness)
#define LED_FAIL    12  // Red indicator (optional)

// ===== CONSTANTS =====
#define VREF        5.0
#define ADC_BITS    1023.0

// ===== OP-AMP DATASHEET SPECS =====
struct OpAmpSpec {
  char name[20];
  int pin_count;
  // Worst-case specs from datasheet
  float max_offset_mv;      // Maximum DC offset allowed
  float min_gain;           // Minimum gain (unity = 1.0)
  float max_gain;           // Maximum gain
  float min_output_swing;   // Minimum output high (%)
};

// Typical datasheet values
OpAmpSpec opamp_specs[] = {
  {"LM324",     14, 50.0,  0.9, 1.1, 80.0},  // ±50mV offset typical
  {"LM358",      8, 50.0,  0.9, 1.1, 80.0},
  {"LM386",      8, 100.0, 15.0, 200.0, 70.0},  // Gain much higher
  {"LM741",      8, 100.0, 0.8, 1.2, 75.0},
  {"TL071",      8, 50.0,  0.9, 1.1, 85.0},
  {"TL072",      8, 50.0,  0.9, 1.1, 85.0},
  {"NE5532",     8, 20.0,  0.9, 1.1, 90.0},
  {"NE5534",     8, 20.0,  0.9, 1.1, 90.0},
  {"OP07",       8, 5.0,   0.9, 1.1, 90.0},   // Ultra precision
  {"OPA2134",    8, 10.0,  0.9, 1.1, 90.0},
  {"CA3140",     8, 30.0,  0.9, 1.1, 85.0}
};

int num_specs = 11;
int selected_opamp = 0;
int selected_channel = 0;

// ===== TEST STATES =====
enum TestState {
  STATE_MENU,
  STATE_SELECT_OPAMP,
  STATE_SELECT_CHANNELS,
  STATE_READY,
  STATE_TESTING,
  STATE_RESULT_PASS,
  STATE_RESULT_FAIL,
  STATE_HISTORY
};

TestState current_state = STATE_MENU;

// ===== TEST RESULT =====
struct TestResult {
  char opamp_name[20];
  int channel;
  float offset_mv;
  float gain;
  float output_swing;
  bool passed;
  unsigned long timestamp;
};

#define MAX_RESULTS 20
TestResult test_history[MAX_RESULTS];
int result_count = 0;

// ===== CONFIGURATION =====
int active_channels = 1;  // How many channels to test (1-4)
int channels_to_test[4] = {0, -1, -1, -1};  // -1 = not used

// ===== UI STATE =====
unsigned long last_btn_time = 0;
#define DEBOUNCE 50

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  // LCD init
  lcd.init();
  lcd.backlight();
  
  // Pin setup
  pinMode(OUT_CH1, OUTPUT);
  pinMode(OUT_CH2, OUTPUT);
  pinMode(OUT_CH3, OUTPUT);
  pinMode(OUT_CH4, OUTPUT);
  
  pinMode(BTN_START, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_MENU, INPUT_PULLUP);
  
  pinMode(LED_OK, OUTPUT);
  pinMode(LED_FAIL, OUTPUT);
  
  // All outputs LOW
  analogWrite(OUT_CH1, 0);
  analogWrite(OUT_CH2, 0);
  analogWrite(OUT_CH3, 0);
  analogWrite(OUT_CH4, 0);
  
  displaySplash();
  delay(2000);
  
  current_state = STATE_MENU;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch(current_state) {
    case STATE_MENU:
      displayMenu();
      break;
    case STATE_SELECT_OPAMP:
      displaySelectOpAmp();
      break;
    case STATE_SELECT_CHANNELS:
      displaySelectChannels();
      break;
    case STATE_READY:
      displayReady();
      break;
    case STATE_TESTING:
      runTest();
      break;
    case STATE_RESULT_PASS:
      displayResultPass();
      break;
    case STATE_RESULT_FAIL:
      displayResultFail();
      break;
    case STATE_HISTORY:
      displayHistory();
      break;
  }
  
  delay(50);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplash() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("  OP-AMP TESTER v6.0");
  lcd.setCursor(0, 1);
  lcd.print("  Simple Functionality");
  lcd.setCursor(0, 2);
  lcd.print("  Just Check if it Works");
  lcd.setCursor(0, 3);
  lcd.print("  Arduino Nano Controlled");
}

void displayMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("=== MAIN MENU ===");
    
    lcd.setCursor(0, 1);
    lcd.print("[1] Test Op-Amp");
    
    lcd.setCursor(0, 2);
    lcd.print("[2] View History");
    
    lcd.setCursor(0, 3);
    lcd.print("Press button to select");
    
    last_update = millis();
  }
}

void displaySelectOpAmp() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("SELECT OP-AMP:");
    
    // Show 3 options
    for (int i = -1; i <= 1; i++) {
      int idx = (selected_opamp + i + num_specs) % num_specs;
      lcd.setCursor(0, i + 2);
      
      if (i == 0) {
        lcd.print(">");
      } else {
        lcd.print(" ");
      }
      
      lcd.print(opamp_specs[idx].name);
      lcd.print(" (");
      lcd.print(opamp_specs[idx].pin_count);
      lcd.print("-pin)");
    }
    
    last_update = millis();
  }
}

void displaySelectChannels() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("HOW MANY CHANNELS?");
    
    lcd.setCursor(0, 1);
    lcd.print("Selected Channels: ");
    lcd.print(active_channels);
    
    lcd.setCursor(0, 2);
    lcd.print("(1=Ch1 only, 2=Ch1&Ch2,");
    
    lcd.setCursor(0, 3);
    lcd.print(" 3=Ch1-3, 4=All channels)");
    
    last_update = millis();
  }
}

void displayReady() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("READY TO TEST");
    
    lcd.setCursor(0, 1);
    lcd.print("Op-Amp: ");
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" (");
    lcd.print(opamp_specs[selected_opamp].pin_count);
    lcd.print("-pin)");
    
    lcd.setCursor(0, 2);
    lcd.print("Channels to test: ");
    lcd.print(active_channels);
    
    lcd.setCursor(0, 3);
    lcd.print("Press START to begin test");
    
    last_update = millis();
  }
}

void displayTesting(int progress) {
  lcd.clear();
  
  lcd.setCursor(0, 0);
  lcd.print("TESTING: ");
  lcd.print(opamp_specs[selected_opamp].name);
  
  lcd.setCursor(0, 1);
  lcd.print("Channel: ");
  lcd.print(selected_channel + 1);
  lcd.print("/");
  lcd.print(active_channels);
  
  lcd.setCursor(0, 2);
  lcd.print("Progress: ");
  int bar = (progress * 16) / 100;
  for (int i = 0; i < bar; i++) lcd.print("=");
  for (int i = bar; i < 16; i++) lcd.print("-");
  
  lcd.setCursor(0, 3);
  switch(progress / 25) {
    case 0: lcd.print("Measuring DC offset..."); break;
    case 1: lcd.print("Testing gain (1x)..."); break;
    case 2: lcd.print("Testing output swing..."); break;
    case 3: lcd.print("Checking response..."); break;
    case 4: lcd.print("Complete!"); break;
  }
}

void displayResultPass() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("✓ TEST PASSED!");
    
    lcd.setCursor(0, 1);
    lcd.print("Op-Amp: ");
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" is GOOD");
    
    lcd.setCursor(0, 2);
    lcd.print("Offset: ");
    if (result_count > 0) {
      lcd.print(test_history[result_count-1].offset_mv, 1);
      lcd.print("mV");
    }
    
    lcd.setCursor(0, 3);
    lcd.print("Press any button to continue");
    
    // Blink LED
    digitalWrite(LED_OK, HIGH);
    
    last_update = millis();
  }
}

void displayResultFail() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("✗ TEST FAILED!");
    
    lcd.setCursor(0, 1);
    lcd.print("Op-Amp: ");
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" is BAD");
    
    lcd.setCursor(0, 2);
    lcd.print("Offset: ");
    if (result_count > 0) {
      lcd.print(test_history[result_count-1].offset_mv, 1);
      lcd.print("mV");
    }
    
    lcd.setCursor(0, 3);
    lcd.print("Press any button to continue");
    
    // Blink LED
    static unsigned long led_time = 0;
    if (millis() - led_time > 200) {
      digitalWrite(LED_FAIL, !digitalRead(LED_FAIL));
      led_time = millis();
    }
    
    last_update = millis();
  }
}

void displayHistory() {
  static unsigned long last_update = 0;
  static int history_page = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("TEST HISTORY");
    
    int start = history_page * 2;
    
    if (start < result_count) {
      lcd.setCursor(0, 1);
      lcd.print("#");
      lcd.print(start + 1);
      lcd.print(": ");
      lcd.print(test_history[start].opamp_name);
      lcd.print(" ");
      lcd.print(test_history[start].passed ? "✓" : "✗");
    }
    
    if (start + 1 < result_count) {
      lcd.setCursor(0, 2);
      lcd.print("#");
      lcd.print(start + 2);
      lcd.print(": ");
      lcd.print(test_history[start + 1].opamp_name);
      lcd.print(" ");
      lcd.print(test_history[start + 1].passed ? "✓" : "✗");
    }
    
    lcd.setCursor(0, 3);
    lcd.print("Page ");
    lcd.print(history_page + 1);
    lcd.print(" | Total: ");
    lcd.print(result_count);
    
    last_update = millis();
  }
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  if (now - last_btn_time < DEBOUNCE) {
    return;
  }
  
  if (digitalRead(BTN_START) == LOW) {
    last_btn_time = now;
    handleStart();
  }
  else if (digitalRead(BTN_NEXT) == LOW) {
    last_btn_time = now;
    handleNext();
  }
  else if (digitalRead(BTN_PREV) == LOW) {
    last_btn_time = now;
    handlePrev();
  }
  else if (digitalRead(BTN_MENU) == LOW) {
    last_btn_time = now;
    handleMenu();
  }
}

void handleStart() {
  digitalWrite(LED_OK, LOW);
  digitalWrite(LED_FAIL, LOW);
  
  switch(current_state) {
    case STATE_MENU:
      current_state = STATE_SELECT_OPAMP;
      selected_opamp = 0;
      break;
    case STATE_SELECT_OPAMP:
      current_state = STATE_SELECT_CHANNELS;
      active_channels = 1;
      break;
    case STATE_SELECT_CHANNELS:
      current_state = STATE_READY;
      break;
    case STATE_READY:
      selected_channel = 0;
      current_state = STATE_TESTING;
      break;
    case STATE_RESULT_PASS:
    case STATE_RESULT_FAIL:
      if (selected_channel < active_channels - 1) {
        selected_channel++;
        current_state = STATE_TESTING;
      } else {
        current_state = STATE_MENU;
      }
      break;
    case STATE_HISTORY:
      current_state = STATE_MENU;
      break;
  }
}

void handleNext() {
  switch(current_state) {
    case STATE_SELECT_OPAMP:
      selected_opamp = (selected_opamp + 1) % num_specs;
      break;
    case STATE_SELECT_CHANNELS:
      active_channels = (active_channels % 4) + 1;
      break;
    case STATE_HISTORY:
      // Next page
      break;
  }
}

void handlePrev() {
  switch(current_state) {
    case STATE_SELECT_OPAMP:
      selected_opamp = (selected_opamp - 1 + num_specs) % num_specs;
      break;
    case STATE_SELECT_CHANNELS:
      active_channels = (active_channels - 2 + 4) % 4 + 1;
      break;
  }
}

void handleMenu() {
  digitalWrite(LED_OK, LOW);
  digitalWrite(LED_FAIL, LOW);
  
  switch(current_state) {
    case STATE_SELECT_OPAMP:
      current_state = STATE_MENU;
      break;
    case STATE_SELECT_CHANNELS:
      current_state = STATE_SELECT_OPAMP;
      break;
    case STATE_READY:
      current_state = STATE_SELECT_CHANNELS;
      break;
    case STATE_RESULT_PASS:
    case STATE_RESULT_FAIL:
      current_state = STATE_MENU;
      break;
    case STATE_HISTORY:
      current_state = STATE_MENU;
      break;
  }
}

// ===== TEST EXECUTION =====
void runTest() {
  int out_pin = getOutputPin(selected_channel);
  int in_pin = getInputPin(selected_channel);
  
  OpAmpSpec& spec = opamp_specs[selected_opamp];
  TestResult& result = test_history[result_count];
  
  // Initialize result
  strcpy(result.opamp_name, spec.name);
  result.channel = selected_channel + 1;
  result.timestamp = millis();
  
  // TEST 1: DC OFFSET (20%)
  displayTesting(20);
  delay(500);
  
  analogWrite(out_pin, 0);  // No signal
  delay(100);
  
  float v_no_signal = 0;
  for (int i = 0; i < 20; i++) {
    v_no_signal += readVoltage(in_pin);
    delay(5);
  }
  v_no_signal /= 20.0;
  result.offset_mv = v_no_signal * 1000;
  
  // TEST 2: GAIN TEST (50%)
  displayTesting(50);
  delay(500);
  
  analogWrite(out_pin, 127);  // 50% = ~2.5V input
  delay(100);
  
  float v_2v5 = readVoltage(in_pin);
  float gain_1 = v_2v5 / 2.5;
  
  analogWrite(out_pin, 255);  // 100% = ~5V input
  delay(100);
  
  float v_5v = readVoltage(in_pin);
  float gain_2 = v_5v / 5.0;
  
  result.gain = (gain_1 + gain_2) / 2.0;
  
  // TEST 3: OUTPUT SWING (75%)
  displayTesting(75);
  delay(500);
  
  analogWrite(out_pin, 255);
  delay(50);
  float v_max = readVoltage(in_pin);
  
  analogWrite(out_pin, 0);
  delay(50);
  float v_min = readVoltage(in_pin);
  
  result.output_swing = (v_max / 5.0) * 100.0;
  
  // TEST 4: RESPONSE TEST (90%)
  displayTesting(90);
  delay(500);
  
  // Quick step response check
  analogWrite(out_pin, 0);
  delay(10);
  analogWrite(out_pin, 255);
  delay(10);
  float response_check = readVoltage(in_pin);
  
  analogWrite(out_pin, 0);
  
  // COMPLETE (100%)
  displayTesting(100);
  delay(500);
  
  // EVALUATE RESULTS
  result.passed = true;
  
  // Check 1: DC Offset within spec
  if (abs(result.offset_mv) > spec.max_offset_mv) {
    result.passed = false;
  }
  
  // Check 2: Gain within spec (for unity gain op-amps)
  if (spec.max_gain < 10.0) {  // Unity gain type
    if (result.gain < spec.min_gain || result.gain > spec.max_gain) {
      result.passed = false;
    }
  }
  
  // Check 3: Output can swing reasonably
  if (result.output_swing < spec.min_output_swing) {
    result.passed = false;
  }
  
  // Check 4: Output not stuck at rail or ground
  if (v_max < 1.0 || v_max > 4.8) {
    result.passed = false;
  }
  
  // Store result
  if (result_count < MAX_RESULTS) {
    result_count++;
  }
  
  // Show result
  delay(500);
  if (result.passed) {
    current_state = STATE_RESULT_PASS;
  } else {
    current_state = STATE_RESULT_FAIL;
  }
}

// ===== HELPER FUNCTIONS =====
int getOutputPin(int channel) {
  switch(channel) {
    case 0: return OUT_CH1;
    case 1: return OUT_CH2;
    case 2: return OUT_CH3;
    case 3: return OUT_CH4;
  }
  return OUT_CH1;
}

int getInputPin(int channel) {
  switch(channel) {
    case 0: return IN_CH1;
    case 1: return IN_CH2;
    case 2: return IN_CH3;
    case 3: return IN_CH4;
  }
  return IN_CH1;
}

float readVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_BITS) * VREF;
}