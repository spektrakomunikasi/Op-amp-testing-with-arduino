# Complete Wiring Diagram - Arduino Nano + Standardized 12V Supply

## Arduino Nano Pinout dengan I2C LCD
