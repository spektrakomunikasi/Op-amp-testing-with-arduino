/*
 * Op-Amp Testing Suite v7.0 - Extended Database + Adjustable Gain
 * Arduino Nano - Simple Functionality Test with Programmable Gain
 * 
 * Features:
 * - 30+ Op-Amp database (dapat ditambah)
 * - Adjustable gain (1x, 2x, 5x, 10x, 20x, 50x, 100x)
 * - Display gain dalam dB (20*log10(gain))
 * - Output voltage display
 * - Pass/Fail indication
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 7.0 - Extended Database + Programmable Gain
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

// ===== LCD (20x4 recommended) =====
#define LCD_ADDR 0x27
#define LCD_COLS 20
#define LCD_ROWS 4

LiquidCrystal_I2C lcd(LCD_ADDR, LCD_COLS, LCD_ROWS);

// ===== ARDUINO PINS =====
#define OUT_CH1     3   // PWM - test signal
#define OUT_CH2     5   // PWM - optional
#define OUT_CH3     6   // PWM - optional
#define OUT_CH4     9   // PWM - optional

#define IN_CH1      A0  // ADC - read output
#define IN_CH2      A1  // ADC - optional
#define IN_CH3      A2  // ADC - optional
#define IN_CH4      A3  // ADC - optional

#define BTN_START   2   // Start test / Select
#define BTN_NEXT    4   // Next option / Increase gain
#define BTN_PREV    7   // Previous / Decrease gain
#define BTN_MENU    8   // Back to menu

#define LED_OK      13  // Green indicator
#define LED_FAIL    12  // Red indicator

// ===== CONSTANTS =====
#define VREF        5.0
#define ADC_BITS    1023.0

// ===== GAIN OPTIONS =====
const float gain_options[] = {1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0};
const char* gain_labels[] = {"1x", "2x", "5x", "10x", "20x", "50x", "100x"};
#define NUM_GAINS 7

// ===== EXTENDED OP-AMP DATABASE =====
struct OpAmpSpec {
  char name[20];
  int pin_count;
  float max_offset_mv;
  float min_gain;
  float max_gain;
  float min_output_swing;
  int max_freq;
  char type[20];  // Single, Dual, Audio, Precision, etc
};

// 30+ Op-Amps database
OpAmpSpec opamp_specs[] = {
  // 8-PIN DUAL SUPPLY OP-AMPS
  {"LM741",     8, 100.0, 0.8, 1.2, 75.0,  1000, "General"},
  {"LM307",     8, 50.0,  0.8, 1.2, 75.0,  500,  "General"},
  {"LM308",     8, 100.0, 0.8, 1.2, 70.0,  1000, "General"},
  {"TL071",     8, 50.0,  0.9, 1.1, 85.0,  100k, "Audio"},
  {"TL072",     8, 50.0,  0.9, 1.1, 85.0,  100k, "Audio"},
  {"TL074",     8, 50.0,  0.9, 1.1, 85.0,  100k, "Audio"},
  {"TL082",     8, 50.0,  0.9, 1.1, 85.0,  1000, "General"},
  {"TL084",     8, 50.0,  0.9, 1.1, 85.0,  1000, "General"},
  {"NE5532",    8, 20.0,  0.9, 1.1, 90.0,  100k, "Audio"},
  {"NE5534",    8, 20.0,  0.9, 1.1, 90.0,  100k, "Audio"},
  {"OP07",      8, 5.0,   0.9, 1.1, 90.0,  1000, "Precision"},
  {"OP27",      8, 3.0,   0.9, 1.1, 90.0,  1000, "Precision"},
  {"LT1057",    8, 5.0,   0.9, 1.1, 85.0,  1000, "Precision"},
  {"LT1058",    8, 5.0,   0.9, 1.1, 85.0,  1000, "Precision"},
  {"OPA1656",   8, 50.0,  0.9, 1.1, 85.0,  10M,  "Audio"},
  {"OPA2107",   8, 5.0,   0.9, 1.1, 90.0,  1000, "Precision"},
  {"OPA2134",   8, 10.0,  0.9, 1.1, 90.0,  100k, "Audio"},
  {"OPA2133",   8, 10.0,  0.9, 1.1, 90.0,  100k, "Audio"},
  {"OPA2228",   8, 20.0,  0.9, 1.1, 85.0,  1000, "Audio"},
  {"OPA2277",   8, 10.0,  0.9, 1.1, 90.0,  100k, "Audio"},
  {"CA3140",    8, 30.0,  0.9, 1.1, 85.0,  10M,  "HighZ"},
  {"CA3130",    8, 50.0,  0.9, 1.1, 85.0,  1000, "HighZ"},
  {"LM833",     8, 50.0,  0.9, 1.1, 85.0,  1000, "Audio"},
  {"MC1458",    8, 100.0, 0.8, 1.2, 75.0,  1000, "General"},
  {"NE5228",    8, 50.0,  0.9, 1.1, 85.0,  1000, "Audio"},
  
  // 8-PIN SINGLE SUPPLY OP-AMPS
  {"LM358",     8, 50.0,  0.9, 1.1, 80.0,  1000, "General"},
  {"LM358A",    8, 50.0,  0.9, 1.1, 85.0,  1000, "General"},
  {"LM2904",    8, 50.0,  0.9, 1.1, 80.0,  1000, "General"},
  {"OPA2333",   8, 50.0,  0.9, 1.1, 90.0,  1000, "Audio"},
  {"NE8072",    8, 50.0,  0.9, 1.1, 85.0,  1000, "Audio"},
  
  // 14-PIN OP-AMPS (Multi-channel)
  {"LM324",     14, 50.0, 0.9, 1.1, 80.0, 1000, "General"},
  {"LM2902",    14, 50.0, 0.9, 1.1, 80.0, 1000, "General"},
  {"LM3900",    14, 100.0, 0.8, 1.2, 75.0, 1000, "General"},
  {"TL074",     14, 50.0, 0.9, 1.1, 85.0, 100k, "Audio"},
  {"TL084",     14, 50.0, 0.9, 1.1, 85.0, 1000, "General"},
};

int num_specs = 35;
int selected_opamp = 0;
int selected_channel = 0;
int selected_gain_idx = 0;  // Index dalam gain_options

// ===== TEST STATES =====
enum TestState {
  STATE_MENU,
  STATE_SELECT_OPAMP,
  STATE_SELECT_CHANNELS,
  STATE_SELECT_GAIN,
  STATE_READY,
  STATE_TESTING,
  STATE_RESULT_PASS,
  STATE_RESULT_FAIL,
  STATE_DISPLAY_OUTPUT,
  STATE_HISTORY
};

TestState current_state = STATE_MENU;

// ===== TEST RESULT =====
struct TestResult {
  char opamp_name[20];
  int channel;
  float gain_set;
  float vin;
  float vout_measured;
  float vout_expected;
  float offset_mv;
  float dB_gain;
  bool passed;
  unsigned long timestamp;
};

#define MAX_RESULTS 30
TestResult test_history[MAX_RESULTS];
int result_count = 0;

// ===== CONFIGURATION =====
int active_channels = 1;
float selected_gain = 1.0;

// ===== UI STATE =====
unsigned long last_btn_time = 0;
#define DEBOUNCE 50

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  // LCD init
  lcd.init();
  lcd.backlight();
  
  // Pin setup
  pinMode(OUT_CH1, OUTPUT);
  pinMode(OUT_CH2, OUTPUT);
  pinMode(OUT_CH3, OUTPUT);
  pinMode(OUT_CH4, OUTPUT);
  
  pinMode(BTN_START, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_MENU, INPUT_PULLUP);
  
  pinMode(LED_OK, OUTPUT);
  pinMode(LED_FAIL, OUTPUT);
  
  // All outputs LOW
  analogWrite(OUT_CH1, 0);
  analogWrite(OUT_CH2, 0);
  analogWrite(OUT_CH3, 0);
  analogWrite(OUT_CH4, 0);
  
  displaySplash();
  delay(2000);
  
  current_state = STATE_MENU;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch(current_state) {
    case STATE_MENU:
      displayMenu();
      break;
    case STATE_SELECT_OPAMP:
      displaySelectOpAmp();
      break;
    case STATE_SELECT_CHANNELS:
      displaySelectChannels();
      break;
    case STATE_SELECT_GAIN:
      displaySelectGain();
      break;
    case STATE_READY:
      displayReady();
      break;
    case STATE_TESTING:
      runTest();
      break;
    case STATE_RESULT_PASS:
      displayResultPass();
      break;
    case STATE_RESULT_FAIL:
      displayResultFail();
      break;
    case STATE_DISPLAY_OUTPUT:
      displayOutputVoltage();
      break;
    case STATE_HISTORY:
      displayHistory();
      break;
  }
  
  delay(50);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplash() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("  OP-AMP TESTER v7.0");
  lcd.setCursor(0, 1);
  lcd.print("  Extended Database");
  lcd.setCursor(0, 2);
  lcd.print("  Programmable Gain");
  lcd.setCursor(0, 3);
  lcd.print("  35+ Op-Amps Supported");
}

void displayMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("=== MAIN MENU ===");
    
    lcd.setCursor(0, 1);
    lcd.print("[1] Test Op-Amp");
    
    lcd.setCursor(0, 2);
    lcd.print("[2] Measure Output");
    
    lcd.setCursor(0, 3);
    lcd.print("[3] View History");
    
    last_update = millis();
  }
}

void displaySelectOpAmp() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("SELECT OP-AMP (");
    lcd.print(selected_opamp + 1);
    lcd.print("/");
    lcd.print(num_specs);
    lcd.print(")");
    
    // Show 3 options
    for (int i = -1; i <= 1; i++) {
      int idx = (selected_opamp + i + num_specs) % num_specs;
      lcd.setCursor(0, i + 2);
      
      if (i == 0) {
        lcd.print(">");
      } else {
        lcd.print(" ");
      }
      
      lcd.print(opamp_specs[idx].name);
      lcd.print(" (");
      lcd.print(opamp_specs[idx].pin_count);
      lcd.print("p)");
    }
    
    last_update = millis();
  }
}

void displaySelectChannels() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("CHANNELS TO TEST:");
    
    lcd.setCursor(0, 1);
    lcd.print("Selected: ");
    lcd.print(active_channels);
    
    lcd.setCursor(0, 2);
    lcd.print("1=Ch1, 2=Ch1-2");
    
    lcd.setCursor(0, 3);
    lcd.print("3=Ch1-3, 4=All");
    
    last_update = millis();
  }
}

void displaySelectGain() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("SELECT GAIN:");
    
    // Show 3 gain options
    for (int i = -1; i <= 1; i++) {
      int idx = (selected_gain_idx + i + NUM_GAINS) % NUM_GAINS;
      lcd.setCursor(0, i + 1);
      
      if (i == 0) {
        lcd.print(">");
      } else {
        lcd.print(" ");
      }
      
      lcd.print(gain_labels[idx]);
      lcd.print(" = ");
      lcd.print((int)(20.0 * log10(gain_options[idx])));
      lcd.print("dB");
    }
    
    last_update = millis();
  }
}

void displayReady() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("READY TO TEST");
    
    lcd.setCursor(0, 1);
    lcd.print("Op: ");
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" Gain: ");
    lcd.print(gain_labels[selected_gain_idx]);
    
    lcd.setCursor(0, 2);
    lcd.print("Channels: ");
    lcd.print(active_channels);
    lcd.print(" | dB: ");
    float db = 20.0 * log10(gain_options[selected_gain_idx]);
    lcd.print((int)db);
    
    lcd.setCursor(0, 3);
    lcd.print("Press START to begin");
    
    last_update = millis();
  }
}

void displayTesting(int progress) {
  lcd.clear();
  
  lcd.setCursor(0, 0);
  lcd.print("TESTING: ");
  lcd.print(opamp_specs[selected_opamp].name);
  
  lcd.setCursor(0, 1);
  lcd.print("Ch: ");
  lcd.print(selected_channel + 1);
  lcd.print("/");
  lcd.print(active_channels);
  lcd.print(" Gain: ");
  lcd.print(gain_labels[selected_gain_idx]);
  
  lcd.setCursor(0, 2);
  lcd.print("Progress: ");
  int bar = (progress * 14) / 100;
  for (int i = 0; i < bar; i++) lcd.print("=");
  for (int i = bar; i < 14; i++) lcd.print("-");
  
  lcd.setCursor(0, 3);
  switch(progress / 25) {
    case 0: lcd.print("DC offset check..."); break;
    case 1: lcd.print("Measuring gain..."); break;
    case 2: lcd.print("Output swing test..."); break;
    case 3: lcd.print("Response check..."); break;
    case 4: lcd.print("Complete!"); break;
  }
}

void displayResultPass() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("✓ PASSED - Op-Amp OK!");
    
    lcd.setCursor(0, 1);
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" Ch");
    lcd.print(selected_channel + 1);
    
    TestResult& res = test_history[result_count - 1];
    
    lcd.setCursor(0, 2);
    lcd.print("Offset: ");
    lcd.print(res.offset_mv, 1);
    lcd.print("mV Gain: ");
    lcd.print(res.dB_gain, 1);
    lcd.print("dB");
    
    lcd.setCursor(0, 3);
    lcd.print("V_in:");
    lcd.print(res.vin, 2);
    lcd.print("V V_out:");
    lcd.print(res.vout_measured, 2);
    lcd.print("V");
    
    // Blink LED
    digitalWrite(LED_OK, HIGH);
    
    last_update = millis();
  }
}

void displayResultFail() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("✗ FAILED - Op-Amp BAD!");
    
    lcd.setCursor(0, 1);
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" Ch");
    lcd.print(selected_channel + 1);
    
    TestResult& res = test_history[result_count - 1];
    
    lcd.setCursor(0, 2);
    lcd.print("Offset: ");
    lcd.print(res.offset_mv, 1);
    lcd.print("mV (limit:");
    lcd.print(opamp_specs[selected_opamp].max_offset_mv, 0);
    lcd.print(")");
    
    lcd.setCursor(0, 3);
    lcd.print("V_out:");
    lcd.print(res.vout_measured, 2);
    lcd.print("V Expected:");
    lcd.print(res.vout_expected, 2);
    lcd.print("V");
    
    // Blink LED
    static unsigned long led_time = 0;
    if (millis() - led_time > 200) {
      digitalWrite(LED_FAIL, !digitalRead(LED_FAIL));
      led_time = millis();
    }
    
    last_update = millis();
  }
}

void displayOutputVoltage() {
  static unsigned long last_update = 0;
  static int measure_progress = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("MEASURE OUTPUT");
    
    int out_pin = getOutputPin(selected_channel);
    int in_pin = getInputPin(selected_channel);
    
    // Sweep input voltage
    int pwm_val = (measure_progress * 255) / 100;
    analogWrite(out_pin, pwm_val);
    delay(100);
    
    float v_in = (pwm_val / 255.0) * VREF;
    float v_out = readVoltage(in_pin);
    float actual_gain = v_out / v_in;
    float db = 20.0 * log10(actual_gain);
    
    lcd.setCursor(0, 1);
    lcd.print("Op: ");
    lcd.print(opamp_specs[selected_opamp].name);
    lcd.print(" Gain: ");
    lcd.print(gain_labels[selected_gain_idx]);
    
    lcd.setCursor(0, 2);
    lcd.print("V_in: ");
    lcd.print(v_in, 2);
    lcd.print("V V_out: ");
    lcd.print(v_out, 2);
    lcd.print("V");
    
    lcd.setCursor(0, 3);
    lcd.print("Actual Gain: ");
    lcd.print((int)actual_gain);
    lcd.print("x = ");
    lcd.print(db, 1);
    lcd.print("dB");
    
    measure_progress++;
    if (measure_progress > 100) {
      measure_progress = 0;
      analogWrite(out_pin, 0);
    }
    
    last_update = millis();
  }
}

void displayHistory() {
  static unsigned long last_update = 0;
  static int history_page = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("TEST HISTORY");
    
    int start = history_page * 2;
    
    if (start < result_count) {
      lcd.setCursor(0, 1);
      lcd.print("#");
      lcd.print(start + 1);
      lcd.print(": ");
      lcd.print(test_history[start].opamp_name);
      lcd.print(" ");
      lcd.print(test_history[start].passed ? "✓" : "✗");
      lcd.print(" ");
      lcd.print(test_history[start].dB_gain, 1);
      lcd.print("dB");
    }
    
    if (start + 1 < result_count) {
      lcd.setCursor(0, 2);
      lcd.print("#");
      lcd.print(start + 2);
      lcd.print(": ");
      lcd.print(test_history[start + 1].opamp_name);
      lcd.print(" ");
      lcd.print(test_history[start + 1].passed ? "✓" : "✗");
      lcd.print(" ");
      lcd.print(test_history[start + 1].dB_gain, 1);
      lcd.print("dB");
    }
    
    lcd.setCursor(0, 3);
    lcd.print("Page ");
    lcd.print(history_page + 1);
    lcd.print(" | Total: ");
    lcd.print(result_count);
    
    last_update = millis();
  }
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  if (now - last_btn_time < DEBOUNCE) {
    return;
  }
  
  if (digitalRead(BTN_START) == LOW) {
    last_btn_time = now;
    handleStart();
  }
  else if (digitalRead(BTN_NEXT) == LOW) {
    last_btn_time = now;
    handleNext();
  }
  else if (digitalRead(BTN_PREV) == LOW) {
    last_btn_time = now;
    handlePrev();
  }
  else if (digitalRead(BTN_MENU) == LOW) {
    last_btn_time = now;
    handleMenu();
  }
}

void handleStart() {
  digitalWrite(LED_OK, LOW);
  digitalWrite(LED_FAIL, LOW);
  
  switch(current_state) {
    case STATE_MENU:
      // Submenu di MENU
      current_state = STATE_SELECT_OPAMP;
      selected_opamp = 0;
      break;
    case STATE_SELECT_OPAMP:
      current_state = STATE_SELECT_CHANNELS;
      active_channels = 1;
      break;
    case STATE_SELECT_CHANNELS:
      current_state = STATE_SELECT_GAIN;
      selected_gain_idx = 0;
      break;
    case STATE_SELECT_GAIN:
      current_state = STATE_READY;
      selected_gain = gain_options[selected_gain_idx];
      break;
    case STATE_READY:
      selected_channel = 0;
      current_state = STATE_TESTING;
      break;
    case STATE_RESULT_PASS:
    case STATE_RESULT_FAIL:
      if (selected_channel < active_channels - 1) {
        selected_channel++;
        current_state = STATE_TESTING;
      } else {
        current_state = STATE_MENU;
      }
      break;
    case STATE_DISPLAY_OUTPUT:
      current_state = STATE_MENU;
      analogWrite(OUT_CH1, 0);
      analogWrite(OUT_CH2, 0);
      analogWrite(OUT_CH3, 0);
      analogWrite(OUT_CH4, 0);
      break;
    case STATE_HISTORY:
      current_state = STATE_MENU;
      break;
  }
}

void handleNext() {
  switch(current_state) {
    case STATE_MENU:
      // Scroll menu
      break;
    case STATE_SELECT_OPAMP:
      selected_opamp = (selected_opamp + 1) % num_specs;
      break;
    case STATE_SELECT_CHANNELS:
      active_channels = (active_channels % 4) + 1;
      break;
    case STATE_SELECT_GAIN:
      selected_gain_idx = (selected_gain_idx + 1) % NUM_GAINS;
      break;
    case STATE_HISTORY:
      // Next page history
      break;
  }
}

void handlePrev() {
  switch(current_state) {
    case STATE_SELECT_OPAMP:
      selected_opamp = (selected_opamp - 1 + num_specs) % num_specs;
      break;
    case STATE_SELECT_CHANNELS:
      active_channels = (active_channels - 2 + 4) % 4 + 1;
      break;
    case STATE_SELECT_GAIN:
      selected_gain_idx = (selected_gain_idx - 1 + NUM_GAINS) % NUM_GAINS;
      break;
  }
}

void handleMenu() {
  digitalWrite(LED_OK, LOW);
  digitalWrite(LED_FAIL, LOW);
  
  switch(current_state) {
    case STATE_MENU:
      // From menu, dapat substate untuk MEASURE OUTPUT
      if (current_state == STATE_MENU) {
        // Switch untuk menu state handling
        // Implementasi menu submenu di sini
      }
      break;
    case STATE_SELECT_OPAMP:
      current_state = STATE_MENU;
      break;
    case STATE_SELECT_CHANNELS:
      current_state = STATE_SELECT_OPAMP;
      break;
    case STATE_SELECT_GAIN:
      current_state = STATE_SELECT_CHANNELS;
      break;
    case STATE_READY:
      current_state = STATE_SELECT_GAIN;
      break;
    case STATE_RESULT_PASS:
    case STATE_RESULT_FAIL:
      current_state = STATE_MENU;
      break;
    case STATE_DISPLAY_OUTPUT:
      current_state = STATE_MENU;
      analogWrite(OUT_CH1, 0);
      analogWrite(OUT_CH2, 0);
      analogWrite(OUT_CH3, 0);
      analogWrite(OUT_CH4, 0);
      break;
    case STATE_HISTORY:
      current_state = STATE_MENU;
      break;
  }
}

// ===== TEST EXECUTION =====
void runTest() {
  int out_pin = getOutputPin(selected_channel);
  int in_pin = getInputPin(selected_channel);
  
  OpAmpSpec& spec = opamp_specs[selected_opamp];
  TestResult& result = test_history[result_count];
  
  // Initialize result
  strcpy(result.opamp_name, spec.name);
  result.channel = selected_channel + 1;
  result.gain_set = selected_gain;
  result.timestamp = millis();
  
  // TEST 1: DC OFFSET (20%)
  displayTesting(20);
  delay(500);
  
  analogWrite(out_pin, 0);
  delay(100);
  
  float v_no_signal = 0;
  for (int i = 0; i < 20; i++) {
    v_no_signal += readVoltage(in_pin);
    delay(5);
  }
  v_no_signal /= 20.0;
  result.offset_mv = v_no_signal * 1000;
  
  // TEST 2: GAIN TEST at set gain (50%)
  displayTesting(50);
  delay(500);
  
  // Test at different input levels
  analogWrite(out_pin, 127);  // ~2.5V
  delay(100);
  float v_out_mid = readVoltage(in_pin);
  float v_in_mid = 2.5;
  
  analogWrite(out_pin, 255);  // ~5V
  delay(100);
  float v_out_high = readVoltage(in_pin);
  float v_in_high = 5.0;
  
  // Calculate actual gain
  float gain_mid = v_out_mid / v_in_mid;
  float gain_high = v_out_high / v_in_high;
  result.vin = v_in_high;
  result.vout_measured = v_out_high;
  
  // For unity gain type (LM741, etc), gain should be ~1x
  // For precision, check if within 10% of expected
  float expected_gain = selected_gain;
  result.vout_expected = v_in_high * expected_gain;
  
  // Calculate dB
  result.dB_gain = 20.0 * log10(gain_high);
  
  // TEST 3: OUTPUT SWING (75%)
  displayTesting(75);
  delay(500);
  
  analogWrite(out_pin, 255);
  delay(50);
  float v_max = readVoltage(in_pin);
  
  analogWrite(out_pin, 0);
  delay(50);
  float v_min = readVoltage(in_pin);
  
  float output_swing = (v_max / 5.0) * 100.0;
  
  // TEST 4: RESPONSE (90%)
  displayTesting(90);
  delay(500);
  
  analogWrite(out_pin, 0);
  delay(10);
  analogWrite(out_pin, 255);
  delay(10);
  float response_check = readVoltage(in_pin);
  
  analogWrite(out_pin, 0);
  
  // COMPLETE (100%)
  displayTesting(100);
  delay(500);
  
  // EVALUATE
  result.passed = true;
  
  // Check offset
  if (abs(result.offset_mv) > spec.max_offset_mv) {
    result.passed = false;
  }
  
  // Check output swing
  if (output_swing < spec.min_output_swing) {
    result.passed = false;
  }
  
  // Check output not stuck
  if (v_max < 1.0 || v_max > 4.8) {
    result.passed = false;
  }
  
  // Store result
  if (result_count < MAX_RESULTS) {
    result_count++;
  }
  
  delay(500);
  if (result.passed) {
    current_state = STATE_RESULT_PASS;
  } else {
    current_state = STATE_RESULT_FAIL;
  }
}

// ===== HELPER FUNCTIONS =====
int getOutputPin(int channel) {
  switch(channel) {
    case 0: return OUT_CH1;
    case 1: return OUT_CH2;
    case 2: return OUT_CH3;
    case 3: return OUT_CH4;
  }
  return OUT_CH1;
}

int getInputPin(int channel) {
  switch(channel) {
    case 0: return IN_CH1;
    case 1: return IN_CH2;
    case 2: return IN_CH3;
    case 3: return IN_CH4;
  }
  return IN_CH1;
}

float readVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_BITS) * VREF;
}