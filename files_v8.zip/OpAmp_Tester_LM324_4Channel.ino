/*
 * Op-Amp Testing Suite v5.0 - LM324 4-Channel Output Control
 * Arduino Nano - Minimal Pin Usage
 * 
 * Arduino Output: 4x Digital + 4x ADC Input ONLY
 * All 4 channels of LM324 tested simultaneously
 * Gain: Fixed 1x (Unity Buffer) controlled by Arduino
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 5.0 - 4-Channel Simplified
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// ===== LCD CONFIGURATION =====
// Support 16x2 atau 20x4
#define LCD_ADDR 0x27
#define LCD_COLS 20
#define LCD_ROWS 4

LiquidCrystal_I2C lcd(LCD_ADDR, LCD_COLS, LCD_ROWS);

// ===== ARDUINO PIN DEFINITIONS =====
// OUTPUT PINS (untuk signal input ke Non-Inverting Input LM324)
#define OUT_CH1     3   // PWM - Channel 1 (Pin 3 LM324)
#define OUT_CH2     5   // PWM - Channel 2 (Pin 5 LM324)
#define OUT_CH3     6   // PWM - Channel 3 (Pin 11 LM324)
#define OUT_CH4     9   // PWM - Channel 4 (Pin 9 LM324)

// INPUT PINS (ADC - dari Output LM324)
#define IN_CH1      A0  // Output Ch1 (Pin 1 LM324)
#define IN_CH2      A1  // Output Ch2 (Pin 7 LM324)
#define IN_CH3      A2  // Output Ch3 (Pin 8 LM324)
#define IN_CH4      A3  // Output Ch4 (Pin 14 LM324)

// BUTTON PINS
#define BTN_UP      2
#define BTN_DOWN    4
#define BTN_TEST    7
#define BTN_MENU    8

#define LED_STATUS  13

// ===== CONSTANTS =====
#define DEBOUNCE_TIME   50
#define ADC_RESOLUTION  1023.0
#define VREF            5.0

// ===== LM324 PIN MAPPING =====
/*
 * LM324 14-pin DIP Configuration:
 * 
 * Channel 1:  NIN=Pin3, INV=Pin2, OUT=Pin1   (Arduino: OUT_CH1, IN_CH1)
 * Channel 2:  NIN=Pin5, INV=Pin6, OUT=Pin7   (Arduino: OUT_CH2, IN_CH2)
 * Channel 3:  NIN=Pin10, INV=Pin9, OUT=Pin8  (Arduino: OUT_CH3, IN_CH3)
 * Channel 4:  NIN=Pin12, INV=Pin11, OUT=Pin14(Arduino: OUT_CH4, IN_CH4)
 * 
 * All Inverting Inputs → Connected to GND (Fixed gain = 1x)
 * All GND pins (4, 11) → External GND
 * VCC (Pin 14) → +5V External
 * 
 * Non-Inverting Inputs → Arduino D3,D5,D6,D9 (PWM)
 * Outputs → Arduino A0,A1,A2,A3 (ADC)
 */

// ===== MENU STATES =====
enum MenuState {
  MENU_MAIN,
  MENU_SELECT_CHANNEL,
  MENU_SHOW_PINS,
  MENU_RUN_TEST,
  MENU_RESULTS,
  MENU_HISTORY
};

MenuState current_menu = MENU_MAIN;
int menu_cursor = 0;
unsigned long last_btn_time = 0;

// ===== CHANNEL CONFIGURATION =====
struct ChannelConfig {
  char name[20];
  int out_pin;      // Arduino output pin (PWM)
  int in_pin;       // Arduino input pin (ADC)
  int ic_out_pin;   // LM324 output pin number
  int ic_nin_pin;   // LM324 non-inverting input pin
  int ic_inv_pin;   // LM324 inverting input pin (always to GND)
};

ChannelConfig channels[] = {
  {"Channel 1", OUT_CH1, IN_CH1, 1, 3, 2},
  {"Channel 2", OUT_CH2, IN_CH2, 7, 5, 6},
  {"Channel 3", OUT_CH3, IN_CH3, 8, 10, 9},
  {"Channel 4", OUT_CH4, IN_CH4, 14, 12, 11}
};

int num_channels = 4;
int selected_channel = 0;

// ===== TEST RESULTS =====
struct TestData {
  int channel;
  float vout_no_signal;
  float vout_at_2v5;
  float vout_at_5v;
  float gain_measured;
  float offset_mv;
  bool passed;
  unsigned long timestamp;
};

TestData results[4];  // Store result untuk 4 channels

// ===== CALIBRATION =====
float adc_cal[4] = {1.0, 1.0, 1.0, 1.0};  // Per-channel calibration
float GAIN_ERROR = 1.0;

// ===== CUSTOM LCD CHARACTERS =====
byte char_check[8] = {0x00, 0x01, 0x03, 0x16, 0x0C, 0x08, 0x00, 0x00};
byte char_cross[8] = {0x00, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x00, 0x00};
byte char_bar[8] = {0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F};

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  // Initialize LCD
  lcd.init();
  lcd.backlight();
  
  // Create custom characters
  lcd.createChar(0, char_check);
  lcd.createChar(1, char_cross);
  lcd.createChar(2, char_bar);
  
  // Setup pins
  pinMode(OUT_CH1, OUTPUT);
  pinMode(OUT_CH2, OUTPUT);
  pinMode(OUT_CH3, OUTPUT);
  pinMode(OUT_CH4, OUTPUT);
  
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_TEST, INPUT_PULLUP);
  pinMode(BTN_MENU, INPUT_PULLUP);
  
  pinMode(LED_STATUS, OUTPUT);
  
  // All outputs LOW at start
  digitalWrite(OUT_CH1, LOW);
  digitalWrite(OUT_CH2, LOW);
  digitalWrite(OUT_CH3, LOW);
  digitalWrite(OUT_CH4, LOW);
  
  displaySplashScreen();
  delay(2000);
  
  current_menu = MENU_MAIN;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch (current_menu) {
    case MENU_MAIN:
      displayMainMenu();
      break;
    case MENU_SELECT_CHANNEL:
      displayChannelSelection();
      break;
    case MENU_SHOW_PINS:
      displayPinDiagram();
      break;
    case MENU_RUN_TEST:
      runChannelTest();
      break;
    case MENU_RESULTS:
      displayTestResults();
      break;
    case MENU_HISTORY:
      displayTestHistory();
      break;
  }
  
  delay(50);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplashScreen() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("LM324 4-Channel Tester");
  lcd.setCursor(0, 1);
  lcd.print("Arduino Nano Control");
  lcd.setCursor(0, 2);
  lcd.print("v5.0 - Simplified");
  lcd.setCursor(0, 3);
  lcd.print("Initializing...");
  
  blinkLED(3);
}

void displayMainMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("=== MAIN MENU ===");
    
    const char* menu_items[] = {
      "1. Test Channel",
      "2. View Pins",
      "3. Results",
      "4. History"
    };
    
    for (int i = 0; i < 3; i++) {
      lcd.setCursor(0, i + 1);
      if (i == menu_cursor) {
        lcd.print(">");
      } else {
        lcd.print(" ");
      }
      lcd.print(menu_items[i]);
    }
    
    last_update = millis();
  }
}

void displayChannelSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("SELECT CHANNEL:");
    
    for (int i = 0; i < num_channels; i++) {
      lcd.setCursor(0, i + 1);
      if (i == selected_channel) {
        lcd.print(">");
      } else {
        lcd.print(" ");
      }
      lcd.print(channels[i].name);
      lcd.print(" (Pin");
      lcd.print(channels[i].ic_nin_pin);
      lcd.print(",");
      lcd.print(channels[i].ic_out_pin);
      lcd.print(")");
    }
    
    last_update = millis();
  }
}

void displayPinDiagram() {
  static unsigned long last_update = 0;
  static int page = 0;
  
  if (millis() - last_update > 1000) {
    lcd.clear();
    
    ChannelConfig& ch = channels[selected_channel];
    
    lcd.setCursor(0, 0);
    lcd.print("LM324 PIN DIAGRAM:");
    lcd.print(ch.name);
    
    lcd.setCursor(0, 1);
    lcd.print("Non-Inv (NIN):");
    lcd.print("Pin ");
    lcd.print(ch.ic_nin_pin);
    
    lcd.setCursor(0, 2);
    lcd.print("Inverting (INV):");
    lcd.print("Pin ");
    lcd.print(ch.ic_inv_pin);
    lcd.print(" → GND");
    
    lcd.setCursor(0, 3);
    lcd.print("Output (OUT):");
    lcd.print("Pin ");
    lcd.print(ch.ic_out_pin);
    
    page++;
    last_update = millis();
  }
}

void displayTestResults() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    TestData& res = results[selected_channel];
    
    lcd.setCursor(0, 0);
    lcd.print("TEST RESULT - ");
    lcd.print(channels[selected_channel].name);
    
    lcd.setCursor(0, 1);
    if (res.passed) {
      lcd.write(0);  // Checkmark
      lcd.print(" PASSED");
    } else {
      lcd.write(1);  // X mark
      lcd.print(" FAILED");
    }
    
    lcd.setCursor(0, 2);
    lcd.print("DC Offset: ");
    lcd.print(res.offset_mv, 1);
    lcd.print("mV");
    
    lcd.setCursor(0, 3);
    lcd.print("Gain: ");
    lcd.print(res.gain_measured, 2);
    lcd.print("x");
    
    last_update = millis();
  }
}

void displayTestHistory() {
  static unsigned long last_update = 0;
  static int history_page = 0;
  
  if (millis() - last_update > 1000) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("TEST HISTORY (Page ");
    lcd.print(history_page + 1);
    lcd.print("/");
    lcd.print((num_channels + 1) / 2);
    lcd.print(")");
    
    int ch1 = history_page * 2;
    int ch2 = ch1 + 1;
    
    if (ch1 < num_channels) {
      lcd.setCursor(0, 1);
      lcd.print(channels[ch1].name);
      lcd.print(": ");
      if (results[ch1].passed) {
        lcd.write(0);
      } else {
        lcd.write(1);
      }
      lcd.print(" ");
      lcd.print(results[ch1].offset_mv, 1);
      lcd.print("mV");
    }
    
    if (ch2 < num_channels) {
      lcd.setCursor(0, 2);
      lcd.print(channels[ch2].name);
      lcd.print(": ");
      if (results[ch2].passed) {
        lcd.write(0);
      } else {
        lcd.write(1);
      }
      lcd.print(" ");
      lcd.print(results[ch2].offset_mv, 1);
      lcd.print("mV");
    }
    
    lcd.setCursor(0, 3);
    lcd.print("UP/DOWN for more pages");
    
    last_update = millis();
  }
}

void displayTestProgress(int channel, int progress) {
  lcd.clear();
  
  lcd.setCursor(0, 0);
  lcd.print("Testing ");
  lcd.print(channels[channel].name);
  lcd.print("...");
  
  lcd.setCursor(0, 1);
  lcd.print("Progress: ");
  lcd.print(progress);
  lcd.print("%");
  
  lcd.setCursor(0, 2);
  int bar_len = (progress * 20) / 100;
  for (int i = 0; i < bar_len; i++) {
    lcd.write(2);  // Bar character
  }
  
  lcd.setCursor(0, 3);
  switch(progress / 25) {
    case 0: lcd.print("Measuring DC offset..."); break;
    case 1: lcd.print("Testing at 2.5V input..."); break;
    case 2: lcd.print("Testing at 5V input..."); break;
    case 3: lcd.print("Calculating gain..."); break;
    case 4: lcd.print("Complete!"); break;
  }
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  if (now - last_btn_time < DEBOUNCE_TIME) {
    return;
  }
  
  if (digitalRead(BTN_UP) == LOW) {
    last_btn_time = now;
    handleButtonUp();
  }
  else if (digitalRead(BTN_DOWN) == LOW) {
    last_btn_time = now;
    handleButtonDown();
  }
  else if (digitalRead(BTN_TEST) == LOW) {
    last_btn_time = now;
    handleButtonTest();
  }
  else if (digitalRead(BTN_MENU) == LOW) {
    last_btn_time = now;
    handleButtonMenu();
  }
}

void handleButtonUp() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor - 1 + 4) % 4;
      break;
    case MENU_SELECT_CHANNEL:
      selected_channel = (selected_channel - 1 + num_channels) % num_channels;
      break;
    case MENU_HISTORY:
      // Scroll history up (implemented via history_page in display function)
      break;
  }
}

void handleButtonDown() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor + 1) % 4;
      break;
    case MENU_SELECT_CHANNEL:
      selected_channel = (selected_channel + 1) % num_channels;
      break;
    case MENU_HISTORY:
      // Scroll history down
      break;
  }
}

void handleButtonTest() {
  blinkLED(2);
  
  switch (current_menu) {
    case MENU_MAIN:
      if (menu_cursor == 0) {
        current_menu = MENU_SELECT_CHANNEL;
        selected_channel = 0;
      }
      break;
    case MENU_SELECT_CHANNEL:
      current_menu = MENU_RUN_TEST;
      break;
    case MENU_SHOW_PINS:
      current_menu = MENU_MAIN;
      break;
  }
}

void handleButtonMenu() {
  blinkLED(1);
  delay(100);
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      if (menu_cursor == 1) {
        current_menu = MENU_SHOW_PINS;
        selected_channel = 0;
      } else if (menu_cursor == 2) {
        current_menu = MENU_RESULTS;
      } else if (menu_cursor == 3) {
        current_menu = MENU_HISTORY;
      }
      break;
    case MENU_SELECT_CHANNEL:
    case MENU_SHOW_PINS:
    case MENU_RESULTS:
    case MENU_HISTORY:
      current_menu = MENU_MAIN;
      break;
  }
}

// ===== TEST EXECUTION =====
void runChannelTest() {
  int channel = selected_channel;
  int out_pin = channels[channel].out_pin;
  int in_pin = channels[channel].in_pin;
  
  displayTestProgress(channel, 0);
  delay(500);
  
  // Test 1: DC Offset (No signal)
  displayTestProgress(channel, 20);
  digitalWrite(out_pin, LOW);
  delay(100);
  float vout_dc = readAnalogVoltage(in_pin);
  results[channel].vout_no_signal = vout_dc;
  results[channel].offset_mv = vout_dc * 1000;
  delay(200);
  
  // Test 2: Measure output at 2.5V input (50% PWM)
  displayTestProgress(channel, 40);
  analogWrite(out_pin, 127);  // 50% duty = ~2.5V
  delay(100);
  float vout_2v5 = readAnalogVoltage(in_pin);
  results[channel].vout_at_2v5 = vout_2v5;
  delay(200);
  
  // Test 3: Measure output at 5V input (100% PWM)
  displayTestProgress(channel, 60);
  analogWrite(out_pin, 255);  // 100% duty = ~5V
  delay(100);
  float vout_5v = readAnalogVoltage(in_pin);
  results[channel].vout_at_5v = vout_5v;
  delay(200);
  
  // Test 4: Calculate gain (Unity buffer = gain ~1.0)
  displayTestProgress(channel, 80);
  float vin_2v5 = 2.5;
  float vin_5v = 5.0;
  
  // Gain should be close to 1.0 (unity buffer)
  float gain1 = vout_2v5 / vin_2v5;
  float gain2 = vout_5v / vin_5v;
  results[channel].gain_measured = (gain1 + gain2) / 2.0;
  
  // Check if gain is within tolerance (0.9x to 1.1x)
  results[channel].passed = (results[channel].gain_measured > 0.85 && 
                             results[channel].gain_measured < 1.15 &&
                             results[channel].offset_mv < 100);
  
  displayTestProgress(channel, 100);
  blinkLED(results[channel].passed ? 5 : 3);
  
  delay(1000);
  
  // Reset output
  analogWrite(out_pin, 0);
  
  current_menu = MENU_RESULTS;
}

// ===== MEASUREMENT FUNCTIONS =====
float readAnalogVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_RESOLUTION) * VREF * adc_cal[pin - A0];
}

void blinkLED(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(100);
    digitalWrite(LED_STATUS, LOW);
    delay(100);
  }
}