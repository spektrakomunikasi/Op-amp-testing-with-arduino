# Standardized Power Supply Configuration v8.0

## KONSEP: Semua Op-Amp pakai 12V Supply

### Keuntungan:
✅ **Konsisten** - Semua op-amp punya kondisi yang sama
✅ **Mudah compare** - Tidak ada perbedaan dari power supply
✅ **Akurat** - Gain berubah langsung dari op-amp, bukan supply
✅ **Simple** - Hanya satu power supply setup
✅ **Safe** - 12V aman untuk semua op-amp

---

## Power Supply Configuration

### SINGLE SUPPLY OP-AMPS
