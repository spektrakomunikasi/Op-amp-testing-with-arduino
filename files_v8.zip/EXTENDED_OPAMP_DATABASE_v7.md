# Extended Op-Amp Database v7.0

## 35+ Op-Amps Supported!

### Database dibagi per kategori:

## DUAL SUPPLY (±15V) - 8PIN

| Op-Amp    | Max Offset | Type      | Freq | Notes |
|-----------|-----------|-----------|------|-------|
| LM741     | ±100mV    | General   | 1kHz | Classic |
| LM307     | ±50mV     | General   | 500Hz | Low offset |
| LM308     | ±100mV    | General   | 1kHz | Compensated |
| TL071     | ±50mV     | Audio     | 100k | Low noise |
| TL072     | ±50mV     | Audio     | 100k | Dual channel |
| TL074     | ±50mV     | Audio     | 100k | Quad channel |
| TL082     | ±50mV     | General   | 1kHz | Fast settling |
| TL084     | ±50mV     | General   | 1kHz | Quad channel |
| NE5532    | ±20mV     | Audio     | 100k | Ultra low noise |
| NE5534    | ±20mV     | Audio     | 100k | High speed |
| OP07      | ±5mV      | Precision | 1kHz | Ultra precision |
| OP27      | ±3mV      | Precision | 1kHz | Very high precision |
| LT1057    | ±5mV      | Precision | 1kHz | Low drift |
| LT1058    | ±5mV      | Precision | 1kHz | Dual precision |
| OPA1656   | ±50mV     | Audio     | 10MHz | Wideband |
| OPA2107   | ±5mV      | Precision | 1kHz | Dual precision |
| OPA2134   | ±10mV     | Audio     | 100k | Audio grade |
| OPA2133   | ±10mV     | Audio     | 100k | Dual audio |
| OPA2228   | ±20mV     | Audio     | 1kHz | Dual audio |
| OPA2277   | ±10mV     | Audio     | 100k | Dual audio |
| CA3140    | ±30mV     | HighZ     | 10M | MOSFET input |
| CA3130    | ±50mV     | HighZ     | 1kHz | High Z |
| LM833     | ±50mV     | Audio     | 1kHz | Low cost audio |
| MC1458    | ±100mV    | General   | 1kHz | Motorola variant |
| NE5228    | ±50mV     | Audio     | 1kHz | Audio dual |

## SINGLE SUPPLY (5V) - 8PIN

| Op-Amp    | Max Offset | Type      | Freq | Notes |
|-----------|-----------|-----------|------|-------|
| LM358     | ±50mV     | General   | 1kHz | Most common |
| LM358A    | ±50mV     | General   | 1kHz | Improved |
| LM2904    | ±50mV     | General   | 1kHz | Dual channel |
| OPA2333   | ±50mV     | Audio     | 1kHz | Audio single |
| NE8072    | ±50mV     | Audio     | 1kHz | Audio variant |

## QUAD (4-CHANNEL) - 14PIN

| Op-Amp    | Max Offset | Type      | Freq | Notes |
|-----------|-----------|-----------|------|-------|
| LM324     | ±50mV     | General   | 1kHz | Classic quad |
| LM2902    | ±50mV     | General   | 1kHz | Improved |
| LM3900    | ±100mV    | General   | 1kHz | Single supply |
| TL074     | ±50mV     | Audio     | 100k | Audio quad |
| TL084     | ±50mV     | General   | 1kHz | General quad |

## Programmable Gain Options
