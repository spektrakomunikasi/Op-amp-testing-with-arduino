# Op-Amp Database & Specifications

## Complete List: 15+ Operational Amplifiers

### Single Supply Op-Amps (5V)

#### 1. LM324 - Low Power 4-Channel