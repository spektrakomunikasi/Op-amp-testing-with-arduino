/*
 * Op-Amp Simple Alive Checker v6.0
 * Arduino Nano - Ultra Minimal
 * 
 * HANYA CEK: IC masih bisa digunakan atau MATI?
 * - Test DC offset
 * - Test responsivitas
 * - Test output range
 * 
 * NOT untuk characterization - lihat datasheet saja!
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 6.0 - Simple Alive Check
 */

#include <Wire.h>
#*
