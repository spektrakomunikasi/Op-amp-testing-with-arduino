# Op-Amp Testing with Arduino v3.0

Sistem pengujian operational amplifier (op-amp) berbasis Arduino Nano dengan LCD 1602 dan navigasi tombol.

**Mendukung 15+ jenis op-amp dengan konfigurasi pin yang fleksibel!**

## ✨ Fitur Utama

- ✅ **15+ Op-Amp Support** - LM324, LM358, LM386, LM741, TL071, TL072, NE5532, OPA2134, dan lebih banyak
- ✅ **LCD 1602 I2C Display** - Menampilkan menu interaktif dan hasil real-time
- ✅ **4 Tombol Navigasi** - UP, DOWN, CONFIRM, CANCEL untuk kontrol mudah
- ✅ **Pin Configuration Guide** - Panduan otomatis konfigurasi pin untuk setiap IC
- ✅ **Flexible Pin Header System** - Mudah menukar IC tanpa perlu re-programming
- ✅ **6 Jenis Test** - Basic, Full Suite, Power Check, Gain, Slew Rate, Frequency
- ✅ **Real-time Progress Bar** - Pantau kemajuan test di LCD
- ✅ **Detailed Results** - Offset voltage, gain, slew rate, output range
- ✅ **Supply Voltage Selection** - Support 5V single supply dan ±15V dual supply

## 🔧 Hardware yang Dibutuhkan

| Komponen | Spesifikasi | Qty |
|----------|-------------|-----|
| Arduino Nano | ATmega328P | 1 |
| LCD 1602 | I2C Module 0x27 | 1 |
| Push Button | Momentary, 6mm | 4 |
| LED | 5mm Red | 1 |
| Resistor 1kΩ | 1/4W | 1 |
| Resistor 10kΩ | 1/4W | 5 |
| Op-Amp | LM324, LM358, dll | 1+ |
| Breadboard | 830 points | 1 |
| Jumper Wires | M-M | 30+ |
| Power Supply | 5V dan/atau ±15V | 1 |

## 📌 Pinout Arduino Nano
