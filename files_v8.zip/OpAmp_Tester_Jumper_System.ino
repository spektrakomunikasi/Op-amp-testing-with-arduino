/*
 * Op-Amp Testing Suite v4.0 - Universal Jumper System
 * Arduino Nano + LCD (16x2 atau 20x4) + Button Navigation
 * 
 * Single Universal Socket dengan Jumper Selectable Pins
 * External Power Supply (5V, ±15V, atau CT)
 * Arduino hanya untuk data logging & display hasil test
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 4.0 - Universal Jumper Edition
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>

// ===== LCD SELECTION =====
// Uncomment salah satu:
#define LCD_16x2    // 16 columns x 2 rows
// #define LCD_20x4    // 20 columns x 4 rows (lebih baik)

#ifdef LCD_16x2
  LiquidCrystal_I2C lcd(0x27, 16, 2);
#else
  LiquidCrystal_I2C lcd(0x27, 20, 4);
#endif

// ===== PIN DEFINITIONS =====
#define BTN_UP          2
#define BTN_DOWN        4
#define BTN_CONFIRM     6
#define BTN_CANCEL      7
#define ADC_INPUT_1     A0
#define ADC_INPUT_2     A1
#define ADC_INPUT_3     A2
#define ADC_INPUT_4     A3
#define TEST_OUTPUT_1   3
#define TEST_OUTPUT_2   5
#define LED_STATUS      13
#define DEBOUNCE_TIME   50

// ===== MENU STATES =====
enum MenuState {
  MENU_MAIN,
  MENU_SELECT_IC,
  MENU_PIN_CONFIG_DISPLAY,
  MENU_WIRING_DIAGRAM,
  MENU_SELECT_SUPPLY,
  MENU_ADC_CHANNEL,
  MENU_SELECT_TEST,
  MENU_RUNNING_TEST,
  MENU_RESULTS,
  MENU_DETAILED_RESULTS
};

MenuState current_menu = MENU_MAIN;
int menu_cursor = 0;
unsigned long last_btn_time = 0;

// ===== UNIVERSAL IC DATABASE =====
struct OpAmpConfig {
  char name[20];
  char part_number[15];
  int pin_count;
  // Pin assignments (gunakan pin number dari IC datasheet)
  int pin_non_inv;
  int pin_inv;
  int pin_output;
  int pin_vcc_pos;
  int pin_vcc_neg;
  int pin_gnd_1;
  int pin_gnd_2;      // Some IC punya 2 GND
  // Specifications
  float typical_gain;
  float typical_offset;
  float typical_slew_rate;
  int max_frequency;
  char supply_type[15];
  int num_channels;
};

// ===== DATABASE: ALL IC TYPES =====
OpAmpConfig all_ics[] = {
  // 14-PIN ICs
  {
    "LM324", "LM324N", 14,
    3, 2, 1, 14, 4, 4, 10,         // Pin numbers sesuai 14-pin DIP
    100.0, 5.0, 0.5, 1000,
    "Single/Dual", 4
  },
  
  // 8-PIN ICs
  {
    "LM358", "LM358N", 8,
    3, 2, 1, 8, 4, 4, 0,           // pin_gnd_2 = 0 (tidak ada 2 GND)
    100.0, 5.0, 0.5, 1000,
    "Single", 2
  },
  {
    "LM386", "LM386N", 8,
    3, 2, 5, 8, 4, 1, 4,           // 2 GND di pin 1 dan 4
    200.0, 50.0, 0.3, 100000,
    "Single", 1
  },
  {
    "LM741", "LM741CN", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 6.0, 0.5, 10000,
    "Dual", 1
  },
  {
    "TL071", "TL071CP", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 20.0, 3.5, 100000,
    "Dual", 1
  },
  {
    "TL072", "TL072CP", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 20.0, 13.0, 100000,
    "Dual", 2
  },
  {
    "NE5532", "NE5532P", 8,
    3, 2, 1, 7, 4, 4, 5,           // 2 GND di pin 4 dan 5
    100.0, 0.5, 8.0, 100000,
    "Dual", 1
  },
  {
    "NE5534", "NE5534P", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 0.5, 13.0, 100000,
    "Dual", 1
  },
  {
    "OP07", "OP07CP", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 0.2, 0.3, 500000,
    "Dual", 1
  },
  {
    "OPA2134", "OPA2134PA", 8,
    3, 2, 1, 8, 4, 4, 0,
    100.0, 1.0, 2.5, 100000,
    "Single", 2
  },
  {
    "CA3140", "CA3140EZ", 8,
    3, 2, 6, 7, 4, 4, 0,
    100.0, 10.0, 9.0, 1000000,
    "Dual", 1
  },
  {
    "OPA2107", "OPA2107PA", 8,
    3, 2, 1, 8, 4, 4, 0,
    100.0, 1.0, 2.0, 100000,
    "Dual", 2
  }
};

int num_ics = 12;
int selected_ic = 0;

// ===== POWER SUPPLY TYPES =====
enum PowerSupply {
  PS_SINGLE_5V,       // +5V only
  PS_DUAL_15V,        // +15V, -15V
  PS_CT_12V,          // +12V, GND, -12V (Center Tap)
  PS_CT_9V,           // +9V, GND, -9V (Center Tap)
  PS_SINGLE_12V,      // +12V only
  PS_SINGLE_9V        // +9V only
};

const char* ps_names[] = {
  "+5V Single",
  "±15V Dual",
  "±12V CT",
  "±9V CT",
  "+12V Single",
  "+9V Single"
};

int num_ps = 6;
int selected_ps = 0;

// ===== ADC CHANNEL SELECTION =====
const char* adc_channels[] = {
  "A0 (Default)",
  "A1",
  "A2",
  "A3"
};
int num_adc = 4;
int selected_adc = 0;

// ===== TEST TYPES =====
const char* test_names[] = {
  "Basic Test",
  "Full Suite",
  "Power Check",
  "Gain (Non-Inv)",
  "Gain (Inverting)",
  "Slew Rate",
  "Frequency",
  "DC Offset"
};
int num_tests = 8;
int selected_test = 0;

// ===== TEST RESULTS =====
struct TestResults {
  char ic_name[20];
  char ps_type[20];
  int adc_channel;
  float vout_dc;
  float gain_non_inv;
  float gain_inv;
  float offset_voltage;
  float slew_rate;
  float max_output_high;
  float max_output_low;
  float frequency_response;
  bool test_passed;
  unsigned long timestamp;
};

TestResults results[10];  // Store last 10 test results
int result_index = 0;

// ===== CALIBRATION =====
float VREF = 5.0;
float ADC_RESOLUTION = 1023.0;
float GAIN_ERROR = 1.0;

// ===== CUSTOM LCD CHARACTERS =====
byte char_cursor[8] = {0x00, 0x04, 0x02, 0x1F, 0x02, 0x04, 0x00, 0x00};
byte char_check[8] = {0x00, 0x01, 0x03, 0x16, 0x0C, 0x08, 0x00, 0x00};
byte char_cross[8] = {0x00, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x00, 0x00};
byte char_bar[8] = {0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F};

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  lcd.init();
  lcd.backlight();
  
  lcd.createChar(0, char_cursor);
  lcd.createChar(1, char_check);
  lcd.createChar(2, char_cross);
  lcd.createChar(3, char_bar);
  
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_CONFIRM, INPUT_PULLUP);
  pinMode(BTN_CANCEL, INPUT_PULLUP);
  
  pinMode(LED_STATUS, OUTPUT);
  pinMode(TEST_OUTPUT_1, OUTPUT);
  pinMode(TEST_OUTPUT_2, OUTPUT);
  
  displaySplashScreen();
  delay(2000);
  
  current_menu = MENU_MAIN;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch (current_menu) {
    case MENU_MAIN:
      displayMainMenu();
      break;
    case MENU_SELECT_IC:
      displayICSelection();
      break;
    case MENU_PIN_CONFIG_DISPLAY:
      displayPinConfiguration();
      break;
    case MENU_WIRING_DIAGRAM:
      displayWiringDiagram();
      break;
    case MENU_SELECT_SUPPLY:
      displaySupplySelection();
      break;
    case MENU_ADC_CHANNEL:
      displayADCChannelSelection();
      break;
    case MENU_SELECT_TEST:
      displayTestSelection();
      break;
    case MENU_RUNNING_TEST:
      runSelectedTest();
      break;
    case MENU_RESULTS:
      displayResults();
      break;
    case MENU_DETAILED_RESULTS:
      displayDetailedResults();
      break;
  }
  
  delay(100);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplashScreen() {
  lcd.clear();
  #ifdef LCD_16x2
    lcd.setCursor(0, 0);
    lcd.print("Op-Amp Tester");
    lcd.setCursor(2, 1);
    lcd.print("v4.0 Jumper");
  #else
    lcd.setCursor(0, 0);
    lcd.print("Op-Amp Testing Suite");
    lcd.setCursor(0, 1);
    lcd.print("v4.0 - Modular");
    lcd.setCursor(0, 2);
    lcd.print("Jumper System");
    lcd.setCursor(0, 3);
    lcd.print("External Power Supply");
  #endif
  blinkLED(3);
}

void displayMainMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    #ifdef LCD_16x2
      const char* menu_items[] = {
        "SELECT IC",
        "PIN CONFIG",
        "WIRING",
        "RUN TEST"
      };
      
      lcd.setCursor(1, 0);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(menu_items[menu_cursor]);
      
      if (menu_cursor < 3) {
        lcd.setCursor(0, 1);
        lcd.print("  ");
        lcd.print(menu_items[menu_cursor + 1]);
      }
    #else
      const char* menu_items[] = {
        "SELECT IC",
        "PIN CONFIGURATION",
        "WIRING DIAGRAM",
        "RUN TEST"
      };
      
      lcd.setCursor(1, 0);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(menu_items[menu_cursor]);
      
      lcd.setCursor(0, 2);
      lcd.print("Select an option");
      
      if (menu_cursor < 3) {
        lcd.setCursor(1, 3);
        lcd.print("Next: ");
        lcd.print(menu_items[menu_cursor + 1]);
      }
    #endif
    
    last_update = millis();
  }
}

void displayICSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(all_ics[selected_ic].name);
      lcd.print(" (");
      lcd.print(all_ics[selected_ic].pin_count);
      lcd.print("p)");
      
      int next_ic = (selected_ic + 1) % num_ics;
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(all_ics[next_ic].name);
    #else
      lcd.setCursor(0, 0);
      lcd.print("SELECT IC:");
      
      lcd.setCursor(1, 1);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(all_ics[selected_ic].name);
      lcd.print(" ");
      lcd.print(all_ics[selected_ic].pin_count);
      lcd.print("-pin");
      
      lcd.setCursor(0, 2);
      lcd.print("Part: ");
      lcd.print(all_ics[selected_ic].part_number);
      
      lcd.setCursor(0, 3);
      lcd.print("Channels: ");
      lcd.print(all_ics[selected_ic].num_channels);
    #endif
    
    last_update = millis();
  }
}

void displayPinConfiguration() {
  static unsigned long last_update = 0;
  static int pin_page = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    OpAmpConfig& ic = all_ics[selected_ic];
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.print(ic.name);
      lcd.print(" PIN CONFIG");
      
      lcd.setCursor(0, 1);
      switch(pin_page) {
        case 0:
          lcd.print("OUT:");
          lcd.print(ic.pin_output);
          lcd.print(" INV:");
          lcd.print(ic.pin_inv);
          lcd.print(" NIN:");
          lcd.print(ic.pin_non_inv);
          break;
        case 1:
          lcd.print("VCC+:");
          lcd.print(ic.pin_vcc_pos);
          lcd.print(" VCC-:");
          lcd.print(ic.pin_vcc_neg);
          break;
        case 2:
          lcd.print("GND:");
          lcd.print(ic.pin_gnd_1);
          if(ic.pin_gnd_2 > 0) {
            lcd.print(",");
            lcd.print(ic.pin_gnd_2);
          }
          lcd.print(" Total:");
          lcd.print(ic.pin_count);
          lcd.print("pin");
          break;
      }
    #else
      lcd.setCursor(0, 0);
      lcd.print("PIN CONFIGURATION:");
      lcd.print(ic.name);
      
      lcd.setCursor(0, 1);
      lcd.print("Output    : Pin ");
      lcd.print(ic.pin_output);
      
      lcd.setCursor(0, 2);
      lcd.print("Inverting : Pin ");
      lcd.print(ic.pin_inv);
      lcd.print("  Non-Inv: Pin ");
      lcd.print(ic.pin_non_inv);
      
      lcd.setCursor(0, 3);
      lcd.print("VCC+:");
      lcd.print(ic.pin_vcc_pos);
      lcd.print(" VCC-:");
      lcd.print(ic.pin_vcc_neg);
      lcd.print(" GND:");
      lcd.print(ic.pin_gnd_1);
      if(ic.pin_gnd_2 > 0) {
        lcd.print(",");
        lcd.print(ic.pin_gnd_2);
      }
    #endif
    
    last_update = millis();
  }
}

void displayWiringDiagram() {
  static unsigned long last_update = 0;
  static int diagram_page = 0;
  
  if (millis() - last_update > 1000) {
    lcd.clear();
    
    OpAmpConfig& ic = all_ics[selected_ic];
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.print("WIRING - ");
      lcd.print(ic.name);
      
      lcd.setCursor(0, 1);
      switch(diagram_page) {
        case 0:
          lcd.print("Pin");
          lcd.print(ic.pin_non_inv);
          lcd.print("->D5 Pin");
          lcd.print(ic.pin_inv);
          lcd.print("->GND");
          break;
        case 1:
          lcd.print("Pin");
          lcd.print(ic.pin_output);
          lcd.print("->A0");
          break;
        case 2:
          lcd.print("Pin");
          lcd.print(ic.pin_vcc_pos);
          lcd.print("->VCC Pin");
          lcd.print(ic.pin_vcc_neg);
          lcd.print("->GND");
          break;
      }
    #else
      lcd.setCursor(0, 0);
      lcd.print("JUMPER WIRING - ");
      lcd.print(ic.name);
      
      lcd.setCursor(0, 1);
      lcd.print("Signal Input (Non-Inv):");
      lcd.setCursor(0, 2);
      lcd.print("  Pin ");
      lcd.print(ic.pin_non_inv);
      lcd.print(" connect to Arduino D5");
      
      lcd.setCursor(0, 3);
      lcd.print("Inverting Input:");
      lcd.print("  Pin ");
      lcd.print(ic.pin_inv);
      lcd.print(" to GND");
    #endif
    
    diagram_page = (diagram_page + 1) % 3;
    last_update = millis();
  }
}

void displaySupplySelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(ps_names[selected_ps]);
      
      int next_ps = (selected_ps + 1) % num_ps;
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(ps_names[next_ps]);
    #else
      lcd.setCursor(0, 0);
      lcd.print("SELECT POWER SUPPLY:");
      
      lcd.setCursor(1, 1);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(ps_names[selected_ps]);
      
      lcd.setCursor(0, 2);
      lcd.print("Use external power supply");
      
      lcd.setCursor(0, 3);
      switch(selected_ps) {
        case PS_SINGLE_5V:
          lcd.print("Connect: +5V to pin ");
          lcd.print(all_ics[selected_ic].pin_vcc_pos);
          break;
        case PS_DUAL_15V:
          lcd.print("Connect: +15V/-15V");
          break;
        case PS_CT_12V:
          lcd.print("Connect: CT ±12V");
          break;
        default:
          lcd.print("See manual for connections");
      }
    #endif
    
    last_update = millis();
  }
}

void displayADCChannelSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.write(0);
      lcd.print(" ADC:");
      lcd.print(adc_channels[selected_adc]);
      
      int next_adc = (selected_adc + 1) % num_adc;
      lcd.setCursor(0, 1);
      lcd.print("  ADC:");
      lcd.print(adc_channels[next_adc]);
    #else
      lcd.setCursor(0, 0);
      lcd.print("SELECT ADC INPUT CHANNEL:");
      
      lcd.setCursor(1, 1);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(adc_channels[selected_adc]);
      
      lcd.setCursor(0, 2);
      lcd.print("Connect IC output pin ");
      lcd.print(all_ics[selected_ic].pin_output);
      lcd.setCursor(0, 3);
      lcd.print("to Arduino ");
      switch(selected_adc) {
        case 0: lcd.print("A0"); break;
        case 1: lcd.print("A1"); break;
        case 2: lcd.print("A2"); break;
        case 3: lcd.print("A3"); break;
      }
    #endif
    
    last_update = millis();
  }
}

void displayTestSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(test_names[selected_test]);
      
      int next_test = (selected_test + 1) % num_tests;
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(test_names[next_test]);
    #else
      lcd.setCursor(0, 0);
      lcd.print("SELECT TEST TYPE:");
      
      lcd.setCursor(1, 1);
      lcd.write(0);
      lcd.print(" ");
      lcd.print(test_names[selected_test]);
      
      lcd.setCursor(0, 2);
      lcd.print("IC: ");
      lcd.print(all_ics[selected_ic].name);
      lcd.print(" | PS: ");
      lcd.print(ps_names[selected_ps]);
      
      lcd.setCursor(0, 3);
      lcd.print("Ready to test - Press OK");
    #endif
    
    last_update = millis();
  }
}

void displayResults() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    TestResults& res = results[result_index];
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.print(res.ic_name);
      
      lcd.setCursor(0, 1);
      if (res.test_passed) {
        lcd.write(1);
        lcd.print(" PASSED");
      } else {
        lcd.write(2);
        lcd.print(" FAILED");
      }
    #else
      lcd.setCursor(0, 0);
      lcd.print("TEST RESULT:");
      
      lcd.setCursor(0, 1);
      lcd.print("IC: ");
      lcd.print(res.ic_name);
      lcd.print(" | ");
      if (res.test_passed) {
        lcd.write(1);
        lcd.print(" PASS");
      } else {
        lcd.write(2);
        lcd.print(" FAIL");
      }
      
      lcd.setCursor(0, 2);
      lcd.print("PS: ");
      lcd.print(res.ps_type);
      lcd.print(" | ADC: A");
      lcd.print(res.adc_channel);
      
      lcd.setCursor(0, 3);
      lcd.print("Offset: ");
      lcd.print(res.offset_voltage, 1);
      lcd.print("mV");
    #endif
    
    last_update = millis();
  }
}

void displayDetailedResults() {
  static unsigned long last_update = 0;
  static int result_page = 0;
  
  if (millis() - last_update > 500) {
    lcd.clear();
    
    TestResults& res = results[result_index];
    
    #ifdef LCD_16x2
      lcd.setCursor(0, 0);
      lcd.print(res.ic_name);
      lcd.print(" - Detailed");
      
      lcd.setCursor(0, 1);
      switch(result_page) {
        case 0:
          lcd.print("Offset: ");
          lcd.print(res.offset_voltage, 1);
          lcd.print("mV");
          break;
        case 1:
          lcd.print("Gain NI: ");
          lcd.print(res.gain_non_inv, 2);
          break;
        case 2:
          lcd.print("Slew: ");
          lcd.print(res.slew_rate, 2);
          lcd.print("V/us");
          break;
        case 3:
          lcd.print("Out High: ");
          lcd.print(res.max_output_high, 2);
          lcd.print("V");
          break;
      }
      result_page = (result_page + 1) % 4;
    #else
      lcd.setCursor(0, 0);
      lcd.print("DETAILED RESULTS - ");
      lcd.print(res.ic_name);
      
      lcd.setCursor(0, 1);
      lcd.print("DC Offset: ");
      lcd.print(res.offset_voltage, 2);
      lcd.print("mV");
      
      lcd.setCursor(0, 2);
      lcd.print("Gain (Non-Inv): ");
      lcd.print(res.gain_non_inv, 2);
      lcd.print("x");
      
      lcd.setCursor(0, 3);
      lcd.print("Slew Rate: ");
      lcd.print(res.slew_rate, 2);
      lcd.print("V/µs | Out: ");
      lcd.print(res.max_output_high, 1);
      lcd.print("V");
    #endif
    
    last_update = millis();
  }
}

void displayTestProgress(const char* test_name, int progress) {
  lcd.clear();
  
  #ifdef LCD_16x2
    lcd.setCursor(0, 0);
    lcd.print(test_name);
    lcd.setCursor(13, 0);
    lcd.print(progress);
    lcd.print("%");
    
    lcd.setCursor(0, 1);
    int bar_length = (progress * 16) / 100;
    for (int i = 0; i < bar_length; i++) {
      lcd.write(3);
    }
  #else
    lcd.setCursor(0, 0);
    lcd.print("RUNNING TEST:");
    lcd.print(test_name);
    
    lcd.setCursor(0, 1);
    lcd.print("Progress: ");
    lcd.print(progress);
    lcd.print("%");
    
    lcd.setCursor(0, 2);
    int bar_length = (progress * 20) / 100;
    for (int i = 0; i < bar_length; i++) {
      lcd.write(3);
    }
    
    lcd.setCursor(0, 3);
    lcd.print("Please wait...");
  #endif
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  if (now - last_btn_time < DEBOUNCE_TIME) {
    return;
  }
  
  if (digitalRead(BTN_UP) == LOW) {
    last_btn_time = now;
    handleButtonUp();
  }
  else if (digitalRead(BTN_DOWN) == LOW) {
    last_btn_time = now;
    handleButtonDown();
  }
  else if (digitalRead(BTN_CONFIRM) == LOW) {
    last_btn_time = now;
    handleButtonConfirm();
  }
  else if (digitalRead(BTN_CANCEL) == LOW) {
    last_btn_time = now;
    handleButtonCancel();
  }
}

void handleButtonUp() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor - 1 + 4) % 4;
      break;
    case MENU_SELECT_IC:
      selected_ic = (selected_ic - 1 + num_ics) % num_ics;
      break;
    case MENU_SELECT_SUPPLY:
      selected_ps = (selected_ps - 1 + num_ps) % num_ps;
      break;
    case MENU_ADC_CHANNEL:
      selected_adc = (selected_adc - 1 + num_adc) % num_adc;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test - 1 + num_tests) % num_tests;
      break;
  }
}

void handleButtonDown() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor + 1) % 4;
      break;
    case MENU_SELECT_IC:
      selected_ic = (selected_ic + 1) % num_ics;
      break;
    case MENU_SELECT_SUPPLY:
      selected_ps = (selected_ps + 1) % num_ps;
      break;
    case MENU_ADC_CHANNEL:
      selected_adc = (selected_adc + 1) % num_adc;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test + 1) % num_tests;
      break;
  }
}

void handleButtonConfirm() {
  blinkLED(2);
  
  switch (current_menu) {
    case MENU_MAIN:
      if (menu_cursor == 0) {
        current_menu = MENU_SELECT_IC;
        selected_ic = 0;
      } else if (menu_cursor == 1) {
        current_menu = MENU_PIN_CONFIG_DISPLAY;
      } else if (menu_cursor == 2) {
        current_menu = MENU_WIRING_DIAGRAM;
      } else if (menu_cursor == 3) {
        current_menu = MENU_SELECT_SUPPLY;
        selected_ps = 0;
      }
      break;
      
    case MENU_SELECT_IC:
      current_menu = MENU_SELECT_SUPPLY;
      selected_ps = 0;
      break;
      
    case MENU_PIN_CONFIG_DISPLAY:
      current_menu = MENU_MAIN;
      break;
      
    case MENU_WIRING_DIAGRAM:
      current_menu = MENU_MAIN;
      break;
      
    case MENU_SELECT_SUPPLY:
      current_menu = MENU_ADC_CHANNEL;
      selected_adc = 0;
      break;
      
    case MENU_ADC_CHANNEL:
      current_menu = MENU_SELECT_TEST;
      selected_test = 0;
      break;
      
    case MENU_SELECT_TEST:
      current_menu = MENU_RUNNING_TEST;
      break;
      
    case MENU_RESULTS:
      current_menu = MENU_DETAILED_RESULTS;
      break;
  }
}

void handleButtonCancel() {
  blinkLED(1);
  delay(100);
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_SELECT_IC:
      current_menu = MENU_MAIN;
      break;
    case MENU_PIN_CONFIG_DISPLAY:
      current_menu = MENU_MAIN;
      break;
    case MENU_WIRING_DIAGRAM:
      current_menu = MENU_MAIN;
      break;
    case MENU_SELECT_SUPPLY:
      current_menu = MENU_MAIN;
      break;
    case MENU_ADC_CHANNEL:
      current_menu = MENU_SELECT_SUPPLY;
      break;
    case MENU_SELECT_TEST:
      current_menu = MENU_MAIN;
      break;
    case MENU_RUNNING_TEST:
      current_menu = MENU_MAIN;
      break;
    case MENU_RESULTS:
      current_menu = MENU_MAIN;
      break;
    case MENU_DETAILED_RESULTS:
      current_menu = MENU_RESULTS;
      break;
  }
}

// ===== TEST EXECUTION =====
void runSelectedTest() {
  lcd.clear();
  
  strcpy(results[result_index].ic_name, all_ics[selected_ic].name);
  strcpy(results[result_index].ps_type, ps_names[selected_ps]);
  results[result_index].adc_channel = selected_adc;
  results[result_index].test_passed = true;
  results[result_index].timestamp = millis();
  
  int adc_pin = ADC_INPUT_1 + selected_adc;  // A0, A1, A2, or A3
  
  switch (selected_test) {
    case 0:
      runBasicTest(adc_pin);
      break;
    case 1:
      runFullTest(adc_pin);
      break;
    case 2:
      runPowerCheck(adc_pin);
      break;
    case 3:
      runGainTestNonInv(adc_pin);
      break;
    case 4:
      runGainTestInv(adc_pin);
      break;
    case 5:
      runSlewRateTest(adc_pin);
      break;
    case 6:
      runFrequencyTest(adc_pin);
      break;
    case 7:
      runDCOffsetTest(adc_pin);
      break;
  }
  
  result_index = (result_index + 1) % 10;  // Cycle through 10 stored results
  current_menu = MENU_RESULTS;
}

void runBasicTest(int adc_pin) {
  displayTestProgress("Basic Test", 0);
  delay(500);
  
  displayTestProgress("DC Offset", 25);
  results[result_index].offset_voltage = measureDCOffset(adc_pin);
  delay(500);
  
  displayTestProgress("Out Range", 50);
  testOutputRange(adc_pin);
  delay(500);
  
  displayTestProgress("Func", 75);
  testBasicFunctionality(adc_pin);
  delay(500);
  
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFullTest(int adc_pin) {
  displayTestProgress("Full Suite", 0);
  delay(500);
  
  displayTestProgress("DC Offset", 15);
  results[result_index].offset_voltage = measureDCOffset(adc_pin);
  delay(300);
  
  displayTestProgress("Gain NI", 30);
  results[result_index].gain_non_inv = measureGainNonInv(adc_pin);
  delay(300);
  
  displayTestProgress("Gain Inv", 45);
  results[result_index].gain_inv = measureGainInv(adc_pin);
  delay(300);
  
  displayTestProgress("Out Range", 60);
  testOutputRange(adc_pin);
  delay(300);
  
  displayTestProgress("Slew Rate", 75);
  results[result_index].slew_rate = measureSlewRate(adc_pin);
  delay(300);
  
  displayTestProgress("Frequency", 90);
  testFrequencyResponse(adc_pin);
  
  displayTestProgress("Complete!", 100);
  blinkLED(5);
  delay(1000);
}

void runPowerCheck(int adc_pin) {
  displayTestProgress("Power Check", 50);
  delay(500);
  lcd.clear();
  #ifdef LCD_20x4
    lcd.setCursor(0, 0);
    lcd.print("Connect power supply");
    lcd.setCursor(0, 1);
    lcd.print("to IC correctly.");
    lcd.setCursor(0, 2);
    lcd.print("Measure voltage");
    lcd.setCursor(0, 3);
    lcd.print("manually with multimeter");
  #endif
  delay(3000);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runGainTestNonInv(int adc_pin) {
  displayTestProgress("Gain NonInv", 50);
  results[result_index].gain_non_inv = measureGainNonInv(adc_pin);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runGainTestInv(int adc_pin) {
  displayTestProgress("Gain Inverting", 50);
  results[result_index].gain_inv = measureGainInv(adc_pin);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runSlewRateTest(int adc_pin) {
  displayTestProgress("Slew Rate", 50);
  results[result_index].slew_rate = measureSlewRate(adc_pin);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFrequencyTest(int adc_pin) {
  displayTestProgress("Frequency", 50);
  testFrequencyResponse(adc_pin);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runDCOffsetTest(int adc_pin) {
  displayTestProgress("DC Offset", 50);
  results[result_index].offset_voltage = measureDCOffset(adc_pin);
  displayTestProgress("Complete!", 100);
  delay(1000);
}

// ===== MEASUREMENT FUNCTIONS =====
float measureDCOffset(int adc_pin) {
  float sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += readAnalogVoltage(adc_pin);
    delayMicroseconds(100);
  }
  return (sum / 50) * 1000;  // Convert to mV
}

float measureGainNonInv(int adc_pin) {
  analogWrite(TEST_OUTPUT_1, 100);
  delay(100);
  float vout = readAnalogVoltage(adc_pin);
  float vin = readAnalogVoltage(ADC_INPUT_1) * (5.0 / 255.0);
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) return vout / vin;
  return 0;
}

float measureGainInv(int adc_pin) {
  analogWrite(TEST_OUTPUT_1, 150);
  delay(100);
  float vout = readAnalogVoltage(adc_pin);
  float vin = readAnalogVoltage(ADC_INPUT_1) * (5.0 / 255.0);
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) return abs(vout / vin);
  return 0;
}

void testOutputRange(int adc_pin) {
  analogWrite(TEST_OUTPUT_1, 255);
  delay(50);
  results[result_index].max_output_high = readAnalogVoltage(adc_pin);
  
  analogWrite(TEST_OUTPUT_1, 0);
  delay(50);
  results[result_index].max_output_low = readAnalogVoltage(adc_pin);
}

float measureSlewRate(int adc_pin) {
  digitalWrite(TEST_OUTPUT_1, HIGH);
  unsigned long t_start = micros();
  
  float target = 4.5;
  float v_current = 0;
  
  while (v_current < target && (micros() - t_start) < 1000) {
    v_current = readAnalogVoltage(adc_pin);
    delayMicroseconds(10);
  }
  
  unsigned long rise_time = micros() - t_start;
  digitalWrite(TEST_OUTPUT_1, LOW);
  
  if (rise_time > 0) {
    return (4.5 / (rise_time / 1000000.0));
  }
  return 0;
}

void testFrequencyResponse(int adc_pin) {
  // Simplified - actual frequency sweep would go here
}

void testBasicFunctionality(int adc_pin) {
  analogWrite(TEST_OUTPUT_1, 127);
  delay(100);
  float output = readAnalogVoltage(adc_pin);
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (output > 0.1) {
    results[result_index].test_passed = true;
  } else {
    results[result_index].test_passed = false;
  }
}

// ===== UTILITY FUNCTIONS =====
float readAnalogVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_RESOLUTION) * VREF * GAIN_ERROR;
}

void blinkLED(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(80);
    digitalWrite(LED_STATUS, LOW);
    delay(80);
  }
}