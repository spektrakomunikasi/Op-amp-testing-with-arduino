/*
 * Op-Amp Testing Suite for Arduino Nano
 * Supports: LM324, LM358, TL072, NE5532, LM741
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 */

#include <Wire.h>
#include <EEPROM.h>

// ===== PIN DEFINITIONS =====
#define ADC_INPUT_1     A0    // Analog input for measurement 1
#define ADC_INPUT_2     A1    // Analog input for measurement 2
#define ADC_INPUT_3     A2    // Analog input for measurement 3
#define ADC_INPUT_4     A3    // Analog input for measurement 4
#define TEST_OUTPUT_1   3     // PWM output for test signal 1
#define TEST_OUTPUT_2   5     // PWM output for test signal 2
#define LED_STATUS      13    // Status LED

// ===== CALIBRATION VALUES =====
float VREF = 5.0;            // Reference voltage (measure and adjust)
float ADC_RESOLUTION = 1023.0;
float GAIN_ERROR = 1.0;      // Calibration factor

// ===== Op-Amp Configuration =====
struct OpAmpConfig {
  char name[20];
  float vcc_positive;
  float vcc_negative;
  float typical_gain;
  float typical_offset;
  float typical_slew_rate;
  int max_frequency;
};

OpAmpConfig opamps[] = {
  {"LM324",    5.0,  0.0, 100.0, 5.0,  0.5, 1000},
  {"LM358",    5.0,  0.0, 100.0, 5.0,  0.5, 1000},
  {"TL072",   15.0, -15.0, 200.0, 2.0, 13.0, 100000},
  {"NE5532",  15.0, -15.0, 200.0, 0.5, 8.0,  100000},
  {"LM741",   15.0, -15.0, 100.0, 6.0,  0.5, 10000}
};

// ===== TEST RESULTS STRUCTURE =====
struct TestResults {
  char opamp_name[20];
  float vcc_positive;
  float vcc_negative;
  float vout_no_signal;
  float gain_non_inv;
  float gain_inv;
  float offset_voltage;
  float slew_rate;
  float max_output_high;
  float max_output_low;
  float frequency_response;
  bool test_passed;
  float timestamp;
};

TestResults last_results;
int selected_opamp = 0;

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  pinMode(LED_STATUS, OUTPUT);
  pinMode(TEST_OUTPUT_1, OUTPUT);
  pinMode(TEST_OUTPUT_2, OUTPUT);
  
  digitalWrite(LED_STATUS, HIGH);
  delay(100);
  digitalWrite(LED_STATUS, LOW);
  
  displayWelcome();
}

// ===== MAIN LOOP =====
void loop() {
  displayMainMenu();
  
  if (Serial.available()) {
    char choice = Serial.read();
    
    switch (choice) {
      case '1':
        selectOpAmp();
        break;
      case '2':
        runBasicTest();
        break;
      case '3':
        runFullTest();
        break;
      case '4':
        displayResults();
        break;
      case '5':
        calibrateSystem();
        break;
      case '6':
        displayManual();
        break;
      default:
        break;
    }
  }
}

// ===== DISPLAY FUNCTIONS =====
void displayWelcome() {
  Serial.println("\n\n");
  Serial.println("╔═══════════════════════════════════════════════════════╗");
  Serial.println("║   Op-Amp Testing Suite - Arduino Nano                 ║");
  Serial.println("║   Supports: LM324, LM358, TL072, NE5532, LM741        ║");
  Serial.println("║   Version: 1.0.0 (2026-03-08)                         ║");
  Serial.println("╚══════════════════════════════���════════════════════════╝");
  Serial.println();
  Serial.println("System initialized successfully!");
  Serial.println("Type any character to continue...\n");
}

void displayMainMenu() {
  Serial.println("\n╔════════════════ MAIN MENU ════════════════╗");
  Serial.println("║ 1. Select Op-Amp                           ║");
  Serial.println("║ 2. Run Basic Test (Output Voltage)         ║");
  Serial.println("║ 3. Run Full Test Suite                     ║");
  Serial.println("║ 4. Display Last Test Results               ║");
  Serial.println("║ 5. Calibrate System                        ║");
  Serial.println("║ 6. Show Manual & Wiring Diagram            ║");
  Serial.println("╚═══════════════════════════════════════════════════════╝");
  Serial.println("Enter choice (1-6): ");
}

void selectOpAmp() {
  Serial.println("\n╔════════════ SELECT Op-AMP ════════════╗");
  for (int i = 0; i < 5; i++) {
    Serial.print("║ ");
    Serial.print(i + 1);
    Serial.print(". ");
    Serial.println(opamps[i].name);
  }
  Serial.println("╚═══════════════════════════════════════╝");
  Serial.println("Enter choice (1-5): ");
  
  while (!Serial.available());
  int choice = Serial.read() - '0';
  
  if (choice >= 1 && choice <= 5) {
    selected_opamp = choice - 1;
    Serial.print("\n✓ Selected: ");
    Serial.println(opamps[selected_opamp].name);
    Serial.println();
  } else {
    Serial.println("\n✗ Invalid choice!");
  }
}

void runBasicTest() {
  Serial.println("\n╔═════════════ BASIC TEST ═════════════╗");
  Serial.print("Op-Amp: ");
  Serial.println(opamps[selected_opamp].name);
  Serial.println();
  
  blinkLED(2);
  
  // Test 1: Power Supply Check
  Serial.println("[1/4] Checking Power Supply...");
  testPowerSupply();
  delay(500);
  
  // Test 2: Output DC Voltage (No Signal)
  Serial.println("[2/4] Measuring Output DC Voltage...");
  float vout_dc = measureOutputDC();
  last_results.vout_no_signal = vout_dc;
  Serial.print("  Output DC: ");
  Serial.print(vout_dc, 3);
  Serial.println(" V");
  delay(500);
  
  // Test 3: Output Voltage Range
  Serial.println("[3/4] Testing Output Voltage Range...");
  testOutputVoltageRange();
  delay(500);
  
  // Test 4: Basic Functionality
  Serial.println("[4/4] Basic Functionality Test...");
  testBasicFunctionality();
  
  Serial.println("\n✓ Basic Test Complete!");
  Serial.println();
}

void runFullTest() {
  Serial.println("\n╔═════════════ FULL TEST SUITE ═════════════╗");
  Serial.print("Op-Amp: ");
  Serial.println(opamps[selected_opamp].name);
  Serial.println();
  
  blinkLED(3);
  
  // Initialize results
  strcpy(last_results.opamp_name, opamps[selected_opamp].name);
  last_results.vcc_positive = opamps[selected_opamp].vcc_positive;
  last_results.vcc_negative = opamps[selected_opamp].vcc_negative;
  last_results.test_passed = true;
  
  // Test 1: Power Supply
  Serial.println("[1/7] Testing Power Supply Pins...");
  testPowerSupply();
  delay(300);
  
  // Test 2: Output DC Voltage
  Serial.println("[2/7] Measuring Output DC Offset Voltage...");
  last_results.vout_no_signal = measureOutputDC();
  last_results.offset_voltage = last_results.vout_no_signal;
  Serial.print("  Offset: ");
  Serial.print(last_results.offset_voltage, 3);
  Serial.println(" mV");
  delay(300);
  
  // Test 3: Gain (Non-Inverting Configuration)
  Serial.println("[3/7] Measuring Gain (Non-Inverting)...");
  last_results.gain_non_inv = measureGainNonInverting();
  Serial.print("  Gain: ");
  Serial.print(last_results.gain_non_inv, 2);
  Serial.println(" V/V");
  delay(300);
  
  // Test 4: Gain (Inverting Configuration)
  Serial.println("[4/7] Measuring Gain (Inverting)...");
  last_results.gain_inv = measureGainInverting();
  Serial.print("  Gain: ");
  Serial.print(last_results.gain_inv, 2);
  Serial.println(" V/V");
  delay(300);
  
  // Test 5: Output Voltage Range
  Serial.println("[5/7] Testing Output Voltage Range...");
  testOutputVoltageRange();
  delay(300);
  
  // Test 6: Slew Rate
  Serial.println("[6/7] Measuring Slew Rate...");
  last_results.slew_rate = measureSlewRate();
  Serial.print("  Slew Rate: ");
  Serial.print(last_results.slew_rate, 3);
  Serial.println(" V/µs");
  delay(300);
  
  // Test 7: Frequency Response
  Serial.println("[7/7] Testing Frequency Response...");
  testFrequencyResponse();
  
  // Summary
  Serial.println("\n╔═════════════ TEST SUMMARY ═════════════╗");
  Serial.print("Op-Amp: ");
  Serial.println(last_results.opamp_name);
  Serial.print("Status: ");
  Serial.println(last_results.test_passed ? "✓ PASSED" : "✗ FAILED");
  Serial.println("╚═══════════════════════════════════════╝\n");
  
  if (last_results.test_passed) {
    blinkLED(5);
  } else {
    blinkLED(1);
    delay(200);
    blinkLED(1);
  }
}

void displayResults() {
  Serial.println("\n╔════════════ LAST TEST RESULTS ════════════╗");
  Serial.print("Op-Amp: ");
  Serial.println(last_results.opamp_name);
  Serial.println();
  Serial.print("VCC+: ");
  Serial.print(last_results.vcc_positive);
  Serial.print("V | VCC-: ");
  Serial.print(last_results.vcc_negative);
  Serial.println("V");
  Serial.println();
  Serial.print("Output DC Offset: ");
  Serial.print(last_results.vout_no_signal, 3);
  Serial.println(" mV");
  Serial.print("Gain (Non-Inv): ");
  Serial.print(last_results.gain_non_inv, 2);
  Serial.println(" V/V");
  Serial.print("Gain (Inv): ");
  Serial.print(last_results.gain_inv, 2);
  Serial.println(" V/V");
  Serial.print("Slew Rate: ");
  Serial.print(last_results.slew_rate, 3);
  Serial.println(" V/µs");
  Serial.println();
  Serial.print("Status: ");
  Serial.println(last_results.test_passed ? "✓ PASSED" : "✗ FAILED");
  Serial.println("╚══════════════════════════════════════════╝\n");
}

void calibrateSystem() {
  Serial.println("\n╔════════════ CALIBRATION ════════════╗");
  Serial.println("Calibration Mode");
  Serial.println();
  Serial.println("Instructions:");
  Serial.println("1. Connect multimeter to A0 (GND reference)");
  Serial.println("2. Measure actual voltage at A0");
  Serial.println("3. Enter measured voltage value");
  Serial.println();
  Serial.println("Enter measured voltage (e.g., 5.00): ");
  
  float measured_vref = 0;
  while (!Serial.available());
  measured_vref = Serial.parseFloat();
  
  if (measured_vref > 0) {
    VREF = measured_vref;
    GAIN_ERROR = VREF / 5.0;
    Serial.println();
    Serial.print("✓ Calibration Complete!");
    Serial.print(" VREF = ");
    Serial.print(VREF, 2);
    Serial.println("V");
  }
  Serial.println();
}

void displayManual() {
  Serial.println("\n╔════════════════ WIRING DIAGRAM ════════════════╗");
  Serial.println();
  Serial.println("ARDUINO NANO PINOUT:");
  Serial.println("┌─────────────────────────────────────────┐");
  Serial.println("│ A0 (ADC0) ──→ Op-Amp Output 1           │");
  Serial.println("│ A1 (ADC1) ──→ Op-Amp Output 2           │");
  Serial.println("│ A2 (ADC2) ──→ Op-Amp Output 3           │");
  Serial.println("│ A3 (ADC3) ──→ Op-Amp Output 4           │");
  Serial.println("│ D3 (PWM)  ──→ Test Signal Output 1      │");
  Serial.println("│ D5 (PWM)  ──→ Test Signal Output 2      │");
  Serial.println("│ D13       ──→ Status LED (+ to 1K res)  │");
  Serial.println("│ GND       ──→ Ground/Reference          │");
  Serial.println("└─────────────────────────────────────────┘");
  Serial.println();
  
  Serial.println("Op-Amp PIN CONNECTIONS:");
  Serial.println();
  Serial.println("Non-Inverting Input  (pin 3) ─ Test Signal or GND");
  Serial.println("Inverting Input      (pin 2) ─ GND or Output");
  Serial.println("Output               (pin 1) ─ to Arduino A0-A3");
  Serial.println("V+ (positive supply) (pin 8) ─ +5V or +15V");
  Serial.println("V- (negative supply) (pin 4) ─ GND or -15V");
  Serial.println();
  
  Serial.println("TEST CIRCUIT EXAMPLE (Unity Gain Buffer):");
  Serial.println("     ┌──────────────┐");
  Serial.println("     │ Non-Inv (3)  │");
  Serial.println("     │   ◄──────────┼──── Test Signal");
  Serial.println("     │              │");
  Serial.println("     │ Op-Amp       │");
  Serial.println("     │              │");
  Serial.println("     │ Inv (2)  ────┼──────┐");
  Serial.println("     │              │      │");
  Serial.println("     │ Output (1)   │      │");
  Serial.println("     └──┬───────────┘      │");
  Serial.println("        │                  │");
  Serial.println("        ├─→ to A0     ←────┘");
  Serial.println("        │");
  Serial.println("       GND");
  Serial.println();
  Serial.println("╚══════════════════════════════════════════╝\n");
}

// ===== TEST FUNCTIONS =====
void testPowerSupply() {
  int vcc_pin = A0;  // Placeholder - measure actual supply
  float vcc_measured = readAnalogVoltage(vcc_pin) * 2;  // Voltage divider
  
  Serial.print("  VCC+: ");
  Serial.print(vcc_measured, 2);
  Serial.println("V");
  
  if (vcc_measured > 4.5 || vcc_measured > 14.0) {
    Serial.println("  ✓ Power Supply OK");
  } else {
    Serial.println("  ✗ Power Supply LOW - Check connections!");
    last_results.test_passed = false;
  }
}

void testBasicFunctionality() {
  // Generate test signal on D3
  analogWrite(TEST_OUTPUT_1, 127);  // 50% duty cycle
  delay(100);
  
  float output = readAnalogVoltage(ADC_INPUT_1);
  analogWrite(TEST_OUTPUT_1, 0);
  
  Serial.print("  Output Response: ");
  Serial.print(output, 3);
  Serial.println("V");
  
  if (output > 0.1) {
    Serial.println("  ✓ Op-Amp is responding");
  } else {
    Serial.println("  ✗ Op-Amp not responding - Check configuration!");
    last_results.test_passed = false;
  }
}

float measureOutputDC() {
  float sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(100);
  }
  return (sum / 50) * 1000;  // Convert to mV
}

float measureGainNonInverting() {
  // Apply test signal
  analogWrite(TEST_OUTPUT_1, 100);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return vout / vin;
  }
  return 0;
}

float measureGainInverting() {
  // Similar to non-inverting but with inverted input
  analogWrite(TEST_OUTPUT_1, 150);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return abs(vout / vin);
  }
  return 0;
}

void testOutputVoltageRange() {
  // Test maximum output high
  analogWrite(TEST_OUTPUT_1, 255);
  delay(50);
  float vout_high = readAnalogVoltage(ADC_INPUT_1);
  
  // Test maximum output low
  analogWrite(TEST_OUTPUT_1, 0);
  delay(50);
  float vout_low = readAnalogVoltage(ADC_INPUT_1);
  
  last_results.max_output_high = vout_high;
  last_results.max_output_low = vout_low;
  
  Serial.print("  Max High: ");
  Serial.print(vout_high, 3);
  Serial.print("V | Max Low: ");
  Serial.print(vout_low, 3);
  Serial.println("V");
}

float measureSlewRate() {
  // Generate square wave and measure rise time
  digitalWrite(TEST_OUTPUT_1, HIGH);
  unsigned long t_start = micros();
  
  // Measure time to reach 90% output
  float target = 4.5;  // 90% of 5V
  float v_current = 0;
  
  while (v_current < target && (micros() - t_start) < 1000) {
    v_current = readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(10);
  }
  
  unsigned long rise_time = micros() - t_start;
  digitalWrite(TEST_OUTPUT_1, LOW);
  
  if (rise_time > 0) {
    return (4.5 / (rise_time / 1000000.0));  // V/µs
  }
  return 0;
}

void testFrequencyResponse() {
  // Test at different frequencies
  float frequencies[] = {100, 1000, 10000};
  float gains[] = {0, 0, 0};
  
  for (int i = 0; i < 3; i++) {
    float frequency = frequencies[i];
    // Generate frequency and measure response
    Serial.print("  ");
    Serial.print(frequency);
    Serial.print("Hz: ");
    
    // Simplified frequency test
    gains[i] = 1.0;  // Placeholder
    Serial.print(gains[i], 2);
    Serial.println("x");
  }
  
  last_results.frequency_response = gains[0];
}

// ===== UTILITY FUNCTIONS =====
float readAnalogVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_RESOLUTION) * VREF * GAIN_ERROR;
}

void blinkLED(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(100);
    digitalWrite(LED_STATUS, LOW);
    delay(100);
  }
}