# Complete Pin Connection Guide for All Op-Amps

## Universal 8-Pin DIP Layout

Sebagian besar op-amp menggunakan layout standar 8-pin DIP:
