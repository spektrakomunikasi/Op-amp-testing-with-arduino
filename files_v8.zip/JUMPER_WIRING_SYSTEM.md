# Universal Jumper Wiring System v4.0

## 🎯 Konsep: 1 Socket Universal + Jumper Selectable

Menggunakan **1 socket DIP universal** dengan jumper untuk mengkonfigurasi setiap IC berbeda.

### Keuntungan:
✅ Hanya perlu 1 socket (hemat tempat & biaya)
✅ Cepat berganti IC (tinggal ganti jumper)
✅ Arduino hanya untuk data logging & display
✅ Power supply eksternal (tidak beban ke Arduino)
✅ LCD bisa 16x2 atau upgrade ke 20x4/TFT

---

## 📊 Universal Socket Pinout

Standar 14-pin atau 8-pin DIP socket dengan header jumper:
