/*
 * Op-Amp Testing Suite with LCD 1602 & Button Navigation
 * Arduino Nano Based
 * 
 * Supports: LM324, LM358, TL072, NE5532, LM741
 * LCD: 16x2 I2C
 * Buttons: UP, DOWN, CONFIRM, CANCEL
 * 
 * Author: spektrakomunikasi
 * Date: 2026-03-08
 * Version: 2.0 (LCD Edition)
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <EEPROM.h>

// ===== LCD CONFIGURATION =====
LiquidCrystal_I2C lcd(0x27, 16, 2);  // Address 0x27, 16 cols, 2 rows
// If LCD doesn't work, try 0x3F instead of 0x27

// ===== PIN DEFINITIONS =====
#define BTN_UP          2     // UP button
#define BTN_DOWN        4     // DOWN button
#define BTN_CONFIRM     6     // CONFIRM button
#define BTN_CANCEL      7     // CANCEL button
#define ADC_INPUT_1     A0    // Analog input for measurement 1
#define ADC_INPUT_2     A1    // Analog input for measurement 2
#define ADC_INPUT_3     A2    // Analog input for measurement 3
#define ADC_INPUT_4     A3    // Analog input for measurement 4
#define TEST_OUTPUT_1   3     // PWM output for test signal 1
#define TEST_OUTPUT_2   5     // PWM output for test signal 2
#define LED_STATUS      13    // Status LED

// ===== BUTTON DEBOUNCING =====
#define DEBOUNCE_TIME   50    // ms
unsigned long last_btn_time = 0;

// ===== CALIBRATION VALUES =====
float VREF = 5.0;
float ADC_RESOLUTION = 1023.0;
float GAIN_ERROR = 1.0;

// ===== MENU STATES =====
enum MenuState {
  MENU_MAIN,
  MENU_SELECT_OPAMP,
  MENU_SELECT_TEST,
  MENU_RUNNING_TEST,
  MENU_RESULTS,
  MENU_DETAILED_RESULTS,
  MENU_CALIBRATION
};

MenuState current_menu = MENU_MAIN;
int menu_cursor = 0;

// ===== Op-Amp Configuration =====
struct OpAmpConfig {
  char name[20];
  float vcc_positive;
  float vcc_negative;
  float typical_gain;
  float typical_offset;
  float typical_slew_rate;
  int max_frequency;
};

OpAmpConfig opamps[] = {
  {"LM324",    5.0,  0.0, 100.0, 5.0,  0.5, 1000},
  {"LM358",    5.0,  0.0, 100.0, 5.0,  0.5, 1000},
  {"TL072",   15.0, -15.0, 200.0, 2.0, 13.0, 100000},
  {"NE5532",  15.0, -15.0, 200.0, 0.5, 8.0,  100000},
  {"LM741",   15.0, -15.0, 100.0, 6.0,  0.5, 10000}
};
int num_opamps = 5;
int selected_opamp = 0;

// ===== TEST MENU =====
const char* test_names[] = {
  "Basic Test",
  "Full Suite",
  "Power Check",
  "Gain Test",
  "Slew Rate",
  "Frequency"
};
int num_tests = 6;
int selected_test = 0;

// ===== TEST RESULTS STRUCTURE =====
struct TestResults {
  char opamp_name[20];
  float vcc_positive;
  float vcc_negative;
  float vout_no_signal;
  float gain_non_inv;
  float gain_inv;
  float offset_voltage;
  float slew_rate;
  float max_output_high;
  float max_output_low;
  float frequency_response;
  bool test_passed;
  int test_progress;
};

TestResults last_results;

// ===== CUSTOM LCD CHARACTERS =====
byte char_cursor[8] = {0x00, 0x04, 0x02, 0x1F, 0x02, 0x04, 0x00, 0x00};
byte char_check[8] = {0x00, 0x01, 0x03, 0x16, 0x0C, 0x08, 0x00, 0x00};
byte char_cross[8] = {0x00, 0x11, 0x0A, 0x04, 0x0A, 0x11, 0x00, 0x00};
byte char_bar[8] = {0x00, 0x1F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1F};

// ===== SETUP =====
void setup() {
  Serial.begin(9600);
  
  // Initialize LCD
  lcd.init();
  lcd.backlight();
  
  // Create custom characters
  lcd.createChar(0, char_cursor);
  lcd.createChar(1, char_check);
  lcd.createChar(2, char_cross);
  lcd.createChar(3, char_bar);
  
  // Initialize pins
  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_CONFIRM, INPUT_PULLUP);
  pinMode(BTN_CANCEL, INPUT_PULLUP);
  
  pinMode(LED_STATUS, OUTPUT);
  pinMode(TEST_OUTPUT_1, OUTPUT);
  pinMode(TEST_OUTPUT_2, OUTPUT);
  
  // Startup sequence
  displaySplashScreen();
  delay(2000);
  
  current_menu = MENU_MAIN;
}

// ===== MAIN LOOP =====
void loop() {
  checkButtons();
  
  switch (current_menu) {
    case MENU_MAIN:
      displayMainMenu();
      break;
    case MENU_SELECT_OPAMP:
      displayOpAmpSelection();
      break;
    case MENU_SELECT_TEST:
      displayTestSelection();
      break;
    case MENU_RUNNING_TEST:
      runSelectedTest();
      break;
    case MENU_RESULTS:
      displayResults();
      break;
    case MENU_DETAILED_RESULTS:
      displayDetailedResults();
      break;
    case MENU_CALIBRATION:
      displayCalibration();
      break;
  }
  
  delay(100);
}

// ===== DISPLAY FUNCTIONS =====
void displaySplashScreen() {
  lcd.clear();
  lcd.setCursor(1, 0);
  lcd.print("Op-Amp Tester");
  lcd.setCursor(2, 1);
  lcd.print("v2.0 - LCD");
  blinkLED(3);
}

void displayMainMenu() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    // Menu items
    const char* menu_items[] = {
      "SELECT OP-AMP",
      "RUN TEST",
      "VIEW RESULTS",
      "CALIBRATE"
    };
    
    // Display current and next item
    lcd.setCursor(1, 0);
    lcd.write(0);  // Cursor character
    lcd.print(" ");
    lcd.print(menu_items[menu_cursor]);
    
    if (menu_cursor < 3) {
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(menu_items[menu_cursor + 1]);
    } else {
      lcd.setCursor(0, 1);
      lcd.print("  ");
      lcd.print(menu_items[0]);
    }
    
    last_update = millis();
  }
}

void displayOpAmpSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    // Display current op-amp
    lcd.setCursor(1, 0);
    lcd.write(0);  // Cursor character
    lcd.print(" ");
    lcd.print(opamps[selected_opamp].name);
    
    // Display next op-amp
    int next_opamp = (selected_opamp + 1) % num_opamps;
    lcd.setCursor(0, 1);
    lcd.print("  ");
    lcd.print(opamps[next_opamp].name);
    
    last_update = millis();
  }
}

void displayTestSelection() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    // Display current test
    lcd.setCursor(1, 0);
    lcd.write(0);  // Cursor character
    lcd.print(" ");
    lcd.print(test_names[selected_test]);
    
    // Display next test
    int next_test = (selected_test + 1) % num_tests;
    lcd.setCursor(0, 1);
    lcd.print("  ");
    lcd.print(test_names[next_test]);
    
    last_update = millis();
  }
}

void displayResults() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    // Line 1: Op-Amp name
    lcd.setCursor(0, 0);
    lcd.print(last_results.opamp_name);
    
    // Line 2: Status
    lcd.setCursor(0, 1);
    if (last_results.test_passed) {
      lcd.write(1);  // Check mark
      lcd.print(" PASSED");
    } else {
      lcd.write(2);  // Cross mark
      lcd.print(" FAILED");
    }
    
    last_update = millis();
  }
}

void displayDetailedResults() {
  static unsigned long last_update = 0;
  static int result_page = 0;
  
  if (millis() - last_update > 300) {
    lcd.clear();
    
    switch (result_page) {
      case 0:
        // Offset voltage
        lcd.setCursor(0, 0);
        lcd.print("Offset: ");
        lcd.print(last_results.offset_voltage, 1);
        lcd.print("mV");
        
        lcd.setCursor(0, 1);
        lcd.print("Gain(NI): ");
        lcd.print(last_results.gain_non_inv, 1);
        break;
        
      case 1:
        // Gain inverting
        lcd.setCursor(0, 0);
        lcd.print("Gain(I): ");
        lcd.print(last_results.gain_inv, 1);
        
        lcd.setCursor(0, 1);
        lcd.print("Slew: ");
        lcd.print(last_results.slew_rate, 2);
        lcd.print("V/us");
        break;
        
      case 2:
        // Output range
        lcd.setCursor(0, 0);
        lcd.print("Out(H): ");
        lcd.print(last_results.max_output_high, 2);
        lcd.print("V");
        
        lcd.setCursor(0, 1);
        lcd.print("Out(L): ");
        lcd.print(last_results.max_output_low, 2);
        lcd.print("V");
        break;
    }
    
    last_update = millis();
  }
}

void displayCalibration() {
  static unsigned long last_update = 0;
  
  if (millis() - last_update > 200) {
    lcd.clear();
    
    lcd.setCursor(0, 0);
    lcd.print("Calibration Mode");
    
    lcd.setCursor(0, 1);
    lcd.print("VREF: ");
    lcd.print(VREF, 2);
    lcd.print("V");
    
    last_update = millis();
  }
}

// ===== BUTTON HANDLER =====
void checkButtons() {
  unsigned long now = millis();
  
  // Debounce check
  if (now - last_btn_time < DEBOUNCE_TIME) {
    return;
  }
  
  // UP Button
  if (digitalRead(BTN_UP) == LOW) {
    last_btn_time = now;
    handleButtonUp();
  }
  
  // DOWN Button
  else if (digitalRead(BTN_DOWN) == LOW) {
    last_btn_time = now;
    handleButtonDown();
  }
  
  // CONFIRM Button
  else if (digitalRead(BTN_CONFIRM) == LOW) {
    last_btn_time = now;
    handleButtonConfirm();
  }
  
  // CANCEL Button
  else if (digitalRead(BTN_CANCEL) == LOW) {
    last_btn_time = now;
    handleButtonCancel();
  }
}

void handleButtonUp() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor - 1 + 4) % 4;
      break;
    case MENU_SELECT_OPAMP:
      selected_opamp = (selected_opamp - 1 + num_opamps) % num_opamps;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test - 1 + num_tests) % num_tests;
      break;
    case MENU_DETAILED_RESULTS:
      // Would scroll up in detailed view
      break;
  }
}

void handleButtonDown() {
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_MAIN:
      menu_cursor = (menu_cursor + 1) % 4;
      break;
    case MENU_SELECT_OPAMP:
      selected_opamp = (selected_opamp + 1) % num_opamps;
      break;
    case MENU_SELECT_TEST:
      selected_test = (selected_test + 1) % num_tests;
      break;
    case MENU_DETAILED_RESULTS:
      // Would scroll down in detailed view
      break;
  }
}

void handleButtonConfirm() {
  blinkLED(2);
  
  switch (current_menu) {
    case MENU_MAIN:
      // Execute main menu selection
      if (menu_cursor == 0) {
        current_menu = MENU_SELECT_OPAMP;
        selected_opamp = 0;
      } else if (menu_cursor == 1) {
        current_menu = MENU_SELECT_TEST;
        selected_test = 0;
      } else if (menu_cursor == 2) {
        current_menu = MENU_RESULTS;
      } else if (menu_cursor == 3) {
        current_menu = MENU_CALIBRATION;
      }
      break;
      
    case MENU_SELECT_OPAMP:
      current_menu = MENU_MAIN;
      break;
      
    case MENU_SELECT_TEST:
      current_menu = MENU_RUNNING_TEST;
      break;
      
    case MENU_RESULTS:
      current_menu = MENU_DETAILED_RESULTS;
      break;
  }
}

void handleButtonCancel() {
  blinkLED(1);
  delay(100);
  blinkLED(1);
  
  switch (current_menu) {
    case MENU_SELECT_OPAMP:
      current_menu = MENU_MAIN;
      break;
    case MENU_SELECT_TEST:
      current_menu = MENU_MAIN;
      break;
    case MENU_RUNNING_TEST:
      // Cancel test (if possible)
      current_menu = MENU_MAIN;
      break;
    case MENU_RESULTS:
      current_menu = MENU_MAIN;
      break;
    case MENU_DETAILED_RESULTS:
      current_menu = MENU_RESULTS;
      break;
    case MENU_CALIBRATION:
      current_menu = MENU_MAIN;
      break;
  }
}

// ===== TEST EXECUTION =====
void runSelectedTest() {
  lcd.clear();
  
  // Initialize results
  strcpy(last_results.opamp_name, opamps[selected_opamp].name);
  last_results.vcc_positive = opamps[selected_opamp].vcc_positive;
  last_results.vcc_negative = opamps[selected_opamp].vcc_negative;
  last_results.test_passed = true;
  last_results.test_progress = 0;
  
  switch (selected_test) {
    case 0:
      runBasicTest();
      break;
    case 1:
      runFullTest();
      break;
    case 2:
      runPowerCheck();
      break;
    case 3:
      runGainTest();
      break;
    case 4:
      runSlewRateTest();
      break;
    case 5:
      runFrequencyTest();
      break;
  }
  
  current_menu = MENU_RESULTS;
}

void runBasicTest() {
  displayTestProgress("Basic Test", 0);
  delay(500);
  
  // Test 1: Power Supply
  displayTestProgress("Checking PSU", 25);
  testPowerSupply();
  delay(500);
  
  // Test 2: Output DC
  displayTestProgress("Measuring DC", 50);
  float vout_dc = measureOutputDC();
  last_results.vout_no_signal = vout_dc;
  delay(500);
  
  // Test 3: Output Range
  displayTestProgress("Out. Range", 75);
  testOutputVoltageRange();
  delay(500);
  
  // Test 4: Functionality
  displayTestProgress("Functionality", 90);
  testBasicFunctionality();
  delay(500);
  
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFullTest() {
  displayTestProgress("Full Suite", 0);
  delay(500);
  
  // 7 comprehensive tests
  const char* test_names[] = {"PSU", "DC", "Gain", "Range", "Slew", "Freq", "Done"};
  
  for (int i = 0; i < 6; i++) {
    displayTestProgress(test_names[i], (i * 15) + 15);
    
    switch (i) {
      case 0: testPowerSupply(); break;
      case 1: last_results.vout_no_signal = measureOutputDC(); break;
      case 2: last_results.gain_non_inv = measureGainNonInverting(); break;
      case 3: testOutputVoltageRange(); break;
      case 4: last_results.slew_rate = measureSlewRate(); break;
      case 5: testFrequencyResponse(); break;
    }
    delay(300);
  }
  
  displayTestProgress("Complete!", 100);
  blinkLED(5);
  delay(1000);
}

void runPowerCheck() {
  displayTestProgress("Power Check", 50);
  testPowerSupply();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runGainTest() {
  displayTestProgress("Gain Test", 33);
  last_results.gain_non_inv = measureGainNonInverting();
  
  displayTestProgress("Gain Test", 66);
  last_results.gain_inv = measureGainInverting();
  
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runSlewRateTest() {
  displayTestProgress("Slew Rate", 50);
  last_results.slew_rate = measureSlewRate();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void runFrequencyTest() {
  displayTestProgress("Frequency", 50);
  testFrequencyResponse();
  displayTestProgress("Complete!", 100);
  delay(1000);
}

void displayTestProgress(const char* test_name, int progress) {
  lcd.clear();
  
  // Line 1: Test name and progress percentage
  lcd.setCursor(0, 0);
  lcd.print(test_name);
  lcd.setCursor(12, 0);
  lcd.print(progress);
  lcd.print("%");
  
  // Line 2: Progress bar
  lcd.setCursor(0, 1);
  int bar_length = (progress * 16) / 100;
  for (int i = 0; i < bar_length; i++) {
    lcd.write(3);  // Bar character
  }
}

// ===== MEASUREMENT FUNCTIONS =====
void testPowerSupply() {
  int vcc_pin = A0;
  float vcc_measured = readAnalogVoltage(vcc_pin) * 2;
  
  if (vcc_measured > 4.5 || vcc_measured > 14.0) {
    last_results.test_passed = true;
  } else {
    last_results.test_passed = false;
  }
}

void testBasicFunctionality() {
  analogWrite(TEST_OUTPUT_1, 127);
  delay(100);
  
  float output = readAnalogVoltage(ADC_INPUT_1);
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (output > 0.1) {
    last_results.test_passed = true;
  } else {
    last_results.test_passed = false;
  }
}

float measureOutputDC() {
  float sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(100);
  }
  return (sum / 50) * 1000;
}

float measureGainNonInverting() {
  analogWrite(TEST_OUTPUT_1, 100);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return vout / vin;
  }
  return 0;
}

float measureGainInverting() {
  analogWrite(TEST_OUTPUT_1, 150);
  delay(100);
  float vout = readAnalogVoltage(ADC_INPUT_1);
  float vin = readAnalogVoltage(TEST_OUTPUT_1) * (5.0 / 255.0);
  
  analogWrite(TEST_OUTPUT_1, 0);
  
  if (vin > 0.1) {
    return abs(vout / vin);
  }
  return 0;
}

void testOutputVoltageRange() {
  analogWrite(TEST_OUTPUT_1, 255);
  delay(50);
  last_results.max_output_high = readAnalogVoltage(ADC_INPUT_1);
  
  analogWrite(TEST_OUTPUT_1, 0);
  delay(50);
  last_results.max_output_low = readAnalogVoltage(ADC_INPUT_1);
}

float measureSlewRate() {
  digitalWrite(TEST_OUTPUT_1, HIGH);
  unsigned long t_start = micros();
  
  float target = 4.5;
  float v_current = 0;
  
  while (v_current < target && (micros() - t_start) < 1000) {
    v_current = readAnalogVoltage(ADC_INPUT_1);
    delayMicroseconds(10);
  }
  
  unsigned long rise_time = micros() - t_start;
  digitalWrite(TEST_OUTPUT_1, LOW);
  
  if (rise_time > 0) {
    return (4.5 / (rise_time / 1000000.0));
  }
  return 0;
}

void testFrequencyResponse() {
  last_results.frequency_response = 1.0;
}

// ===== UTILITY FUNCTIONS =====
float readAnalogVoltage(int pin) {
  int raw = analogRead(pin);
  return (raw / ADC_RESOLUTION) * VREF * GAIN_ERROR;
}

void blinkLED(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_STATUS, HIGH);
    delay(80);
    digitalWrite(LED_STATUS, LOW);
    delay(80);
  }
}